import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, MapPin, Clock, Shield, CheckCircle } from 'lucide-react';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { PageLoader } from '@/components/LoadingSpinner';

export default function Providers() {
  const { data: providers, isLoading } = useQuery({
    queryKey: ['/api/providers'],
  });

  if (isLoading) {
    return <PageLoader text="Loading our trusted service providers..." />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-green-50">
      <Navbar />
      <div className="max-w-7xl mx-auto p-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Our Trusted Service Providers
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Meet our carefully vetted network of professional cleaning specialists. 
            Each provider is licensed, insured, and committed to delivering exceptional service.
          </p>
        </div>

        {/* Providers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {providers?.map((provider) => (
            <Card key={provider.id} className="group hover:shadow-2xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm hover:bg-white hover:scale-105">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <img
                        src={provider.profileImage || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=80&h=80&fit=crop&crop=face'}
                        alt={provider.businessName}
                        className="w-16 h-16 rounded-full object-cover ring-4 ring-blue-100"
                      />
                      {provider.isVerified && (
                        <CheckCircle className="absolute -bottom-1 -right-1 w-6 h-6 text-green-500 bg-white rounded-full" />
                      )}
                    </div>
                    <div>
                      <CardTitle className="text-xl text-gray-900 group-hover:text-blue-600 transition-colors">
                        {provider.businessName}
                      </CardTitle>
                      <div className="flex items-center space-x-1 mt-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        <span className="text-sm font-medium text-gray-700">
                          {provider.rating} ({provider.totalReviews} reviews)
                        </span>
                      </div>
                    </div>
                  </div>
                  {provider.isVerified && (
                    <Badge className="bg-green-100 text-green-800 border-green-200">
                      <Shield className="w-3 h-3 mr-1" />
                      Verified
                    </Badge>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <CardDescription className="text-gray-600 line-clamp-3">
                  {provider.description}
                </CardDescription>

                {/* Specialties */}
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Specialties</h4>
                  <div className="flex flex-wrap gap-2">
                    {provider.specialties?.slice(0, 3).map((specialty, index) => (
                      <Badge key={index} variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                        {specialty}
                      </Badge>
                    ))}
                    {provider.specialties?.length > 3 && (
                      <Badge variant="outline" className="text-xs bg-gray-50 text-gray-600">
                        +{provider.specialties.length - 3} more
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Service Areas */}
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>
                    {provider.serviceAreas?.slice(0, 2).join(', ')}
                    {provider.serviceAreas?.length > 2 && ` +${provider.serviceAreas.length - 2} more`}
                  </span>
                </div>

                {/* Working Hours */}
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  <span>{provider.workingHours}</span>
                </div>

                {/* Hourly Rate */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div>
                    <span className="text-2xl font-bold text-gray-900">${provider.hourlyRate}</span>
                    <span className="text-sm text-gray-500">/hour</span>
                  </div>
                  <Button className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white px-6">
                    Book Now
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-white">
            <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-xl mb-6 opacity-90">
              Book your cleaning service today and experience the difference our professionals make.
            </p>
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-50 px-8 py-3 text-lg">
              Browse All Services
            </Button>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}