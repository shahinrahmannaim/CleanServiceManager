import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, Clock, DollarSign, CheckCircle } from 'lucide-react';
import { Link } from 'wouter';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { PageLoader } from '@/components/LoadingSpinner';

export default function Services() {
  const { data: services, isLoading } = useQuery({
    queryKey: ['/api/services'],
  });

  if (isLoading) {
    return <PageLoader text="Loading our cleaning services..." />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-red-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto p-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Our Cleaning Services
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Professional cleaning services tailored to your needs. 
            From regular maintenance to deep cleaning, we've got you covered.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services?.map((service) => (
            <Card key={service.id} className="group hover:shadow-2xl transition-all duration-300 border-0 bg-white/80 backdrop-blur-sm hover:bg-white hover:scale-105">
              <CardHeader className="pb-4">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl text-gray-900 group-hover:text-blue-900 transition-colors">
                      {service.name}
                    </CardTitle>
                    <div className="flex items-center space-x-2 mt-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">{service.duration} minutes</span>
                    </div>
                  </div>
                  {service.isActive && (
                    <Badge className="bg-green-100 text-green-800 border-green-200">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Available
                    </Badge>
                  )}
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <CardDescription className="text-gray-600 line-clamp-3">
                  {service.description}
                </CardDescription>

                {/* Category */}
                <div>
                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                    {service.category}
                  </Badge>
                </div>

                {/* Image */}
                {service.imageUrl && (
                  <div className="relative h-40 rounded-lg overflow-hidden">
                    <img
                      src={service.imageUrl}
                      alt={service.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                  </div>
                )}

                {/* Price */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="flex items-center space-x-1">
                    <DollarSign className="w-5 h-5 text-gray-500" />
                    <span className="text-2xl font-bold text-gray-900">{service.price}</span>
                    <span className="text-sm text-gray-500">starting</span>
                  </div>
                  <Link href={`/book/${service.id}`}>
                    <Button className="bg-red-500 hover:bg-red-600 text-white px-6">
                      Book Now
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="panorama-gradient rounded-2xl p-8 text-white">
            <h2 className="text-3xl font-bold mb-4">Need a Custom Service?</h2>
            <p className="text-xl mb-6 opacity-90">
              Don't see exactly what you're looking for? Contact us for a personalized cleaning solution.
            </p>
            <Button size="lg" className="bg-white text-blue-900 hover:bg-gray-50 px-8 py-3 text-lg">
              Contact Us
            </Button>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}