import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Search, MapPin, Sparkles, Star, Zap, Clock, Shield, CheckCircle, ArrowRight, Users, Award, Headphones, Phone, Mail, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import Fuse from "fuse.js";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ServiceMap from "@/components/ServiceMap";
import logoImage from "@assets/WhatsApp Image 2025-06-23 at 09.05.23_1750847082310.jpeg";

export default function Home() {
  const [stats, setStats] = useState({
    projectsCompleted: 0,
    professionalTeams: 0,
    satisfiedCustomers: 0,
    awards: 0
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedLocation, setSelectedLocation] = useState("");

  const { data: services = [] } = useQuery({
    queryKey: ['/api/services'],
  });

  // Fuse.js configuration for fuzzy search
  const fuse = useMemo(() => {
    if (!services.length) return null;
    
    return new Fuse(services, {
      keys: [
        { name: 'name', weight: 0.7 },
        { name: 'description', weight: 0.3 }
      ],
      threshold: 0.3,
      includeScore: true,
      includeMatches: true
    });
  }, [services]);

  // Filter services based on search query
  const filteredServices = useMemo(() => {
    if (!searchQuery.trim()) {
      return services;
    }
    
    if (!fuse) return [];
    
    const results = fuse.search(searchQuery);
    return results.map(result => result.item);
  }, [services, searchQuery, fuse]);

  const qatarCities = [
    "Doha", "Al Rayyan", "Al Wakrah", "Umm Salal", "Al Khor", 
    "Al Daayen", "Madinat ash Shamal", "Al Shahaniya"
  ];

  // Animate stats on load
  useEffect(() => {
    const timer = setTimeout(() => {
      setStats({
        projectsCompleted: 10000,
        professionalTeams: 240,
        satisfiedCustomers: 8000,
        awards: 80
      });
    }, 1000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1628744876497-eb30460be9f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"
            alt="Modern office cleaning"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 via-blue-800/70 to-transparent"></div>
        </div>
        
        {/* Floating Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-32 h-32 bg-white/10 rounded-full animate-pulse"></div>
          <div className="absolute bottom-32 right-32 w-24 h-24 bg-orange-400/20 rounded-full animate-bounce"></div>
          <div className="absolute top-1/2 left-20 w-16 h-16 bg-blue-300/20 rounded-full"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-center lg:text-left text-white">
              <div className="inline-flex items-center px-4 py-2 bg-white/20 backdrop-blur-sm text-white rounded-full text-sm font-medium mb-6 border border-white/30">
                <Sparkles className="w-4 h-4 mr-2" />
                Qatar's #1 Cleaning Service
              </div>
              
              <h1 className="text-5xl lg:text-6xl font-bold mb-6 leading-tight">
                Professional<br />
                <span className="text-orange-400">
                  Cleaning Services
                </span>
              </h1>
              
              <p className="text-xl text-blue-100 mb-8 max-w-lg mx-auto lg:mx-0 leading-relaxed">
                Experience Qatar's premier cleaning service. Professional, reliable, and eco-friendly solutions for your home and office.
              </p>

              {/* Search Interface */}
              <div className="bg-white/95 backdrop-blur-sm p-6 rounded-2xl shadow-xl border border-white/20 mb-8">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Choose Location</label>
                    <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                      <SelectTrigger className="w-full h-12 text-base font-medium bg-gray-50 hover:bg-gray-100 text-gray-700 border-2 border-gray-200 rounded-xl">
                        <MapPin className="w-5 h-5 mr-2 text-gray-400" />
                        <SelectValue placeholder="Select your city" />
                      </SelectTrigger>
                      <SelectContent className="bg-white border border-gray-200 rounded-xl shadow-2xl">
                        {qatarCities.map((city) => (
                          <SelectItem 
                            key={city} 
                            value={city.toLowerCase()}
                            className="hover:bg-blue-50 cursor-pointer py-3 px-4 rounded-lg"
                          >
                            {city}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="flex-1">
                    <label className="block text-sm font-medium text-gray-700 mb-2">Find Services</label>
                    <Button 
                      size="lg" 
                      className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white px-8 py-4 text-base font-semibold h-12 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={!selectedLocation}
                    >
                      <Search className="w-5 h-5 mr-2" />
                      Find Services
                    </Button>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 text-center">
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4 border border-white/30">
                  <div className="text-3xl font-bold text-white">10K+</div>
                  <div className="text-sm text-blue-100">Happy Customers</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4 border border-white/30">
                  <div className="text-3xl font-bold text-white">500+</div>
                  <div className="text-sm text-blue-100">Professional Team</div>
                </div>
                <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4 border border-white/30">
                  <div className="text-3xl font-bold text-white">20+</div>
                  <div className="text-sm text-blue-100">Years Experience</div>
                </div>
              </div>
            </div>

            {/* Right Visual */}
            <div className="relative hidden lg:block">
              <div className="relative z-10 bg-white/10 backdrop-blur-sm rounded-3xl shadow-2xl p-8 border border-white/20">
                <img 
                  src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                  alt="Professional cleaning team"
                  className="w-full h-96 object-cover rounded-2xl"
                />
                
                {/* Floating Elements */}
                <div className="absolute -top-4 -right-4 bg-orange-500 text-white p-4 rounded-2xl shadow-lg animate-pulse">
                  <div className="text-2xl font-bold">4.9★</div>
                  <div className="text-sm">Rating</div>
                </div>
                
                <div className="absolute -bottom-4 -left-4 bg-blue-600 text-white p-4 rounded-2xl shadow-lg animate-bounce">
                  <div className="text-2xl font-bold">24/7</div>
                  <div className="text-sm">Support</div>
                </div>
              </div>
              
              {/* Background Decoration */}
              <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-orange-200/30 rounded-3xl transform rotate-3 scale-105 -z-10"></div>
            </div>
          </div>
        </div>
      </section>

      {/* About Section with Video */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4">
                  <div className="aspect-square bg-cover bg-center rounded-lg overflow-hidden"
                    style={{
                      backgroundImage: `url('https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80')`
                    }}>
                  </div>
                  <div className="aspect-video bg-cover bg-center rounded-lg overflow-hidden"
                    style={{
                      backgroundImage: `url('https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80')`
                    }}>
                  </div>
                </div>
                <div className="aspect-[3/4] bg-cover bg-center rounded-lg overflow-hidden relative"
                  style={{
                    backgroundImage: `url('https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80')`
                  }}>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform duration-300">
                      <div className="w-0 h-0 border-l-[12px] border-l-white border-t-[8px] border-t-transparent border-b-[8px] border-b-transparent ml-1"></div>
                    </button>
                  </div>
                </div>
              </div>
              
              {/* Experience Badge */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-lg p-4 shadow-xl border">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center">
                    <Clock className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-gray-900">20+</div>
                    <div className="text-sm text-gray-600">Year of Experience</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div>
              <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
                Cleaning Today Making
                <span className="block text-gray-900">Future Excellent</span>
              </h2>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution.
              </p>
              
              <div className="bg-gray-50 p-6 rounded-lg mb-8 italic">
                <p className="text-gray-700 font-medium">
                  When you work with Clary Cleaning you can cross a major chore off your list, cleaning your home.
                </p>
              </div>
              
              <p className="text-gray-600 mb-8 leading-relaxed">
                It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
              </p>
              
              <Button className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3">
                Learn more
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Professional cleaner"
                className="w-full rounded-lg"
              />
            </div>
            
            <div>
              <div className="bg-blue-600 text-white px-6 py-3 rounded-t-lg">
                <h2 className="text-2xl font-bold">Explore Your Services and Resource</h2>
              </div>
              
              <div className="bg-white border border-gray-200 rounded-b-lg p-6">
                <div className="grid grid-cols-2 gap-6">
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                      alt="Bedroom cleaning"
                      className="w-16 h-16 rounded object-cover"
                    />
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">Bedroom Cleaning</h3>
                      <p className="text-sm text-gray-600">There are many variations of passages of Lorem Ipsum available, but the majority have suffered..</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                      alt="Window cleaning"
                      className="w-16 h-16 rounded object-cover"
                    />
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">Window Cleaning</h3>
                      <p className="text-sm text-gray-600">There are many variations of passages of Lorem Ipsum available, but the majority have suffered..</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                      alt="Office cleaning"
                      className="w-16 h-16 rounded object-cover"
                    />
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">Office Cleaning</h3>
                      <p className="text-sm text-gray-600">There are many variations of passages of Lorem Ipsum available, but the majority have suffered..</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                      alt="Commercial cleaning"
                      className="w-16 h-16 rounded object-cover"
                    />
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">Commercial Cleaning</h3>
                      <p className="text-sm text-gray-600">There are many variations of passages of Lorem Ipsum available, but the majority have suffered..</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                      alt="House cleaning"
                      className="w-16 h-16 rounded object-cover"
                    />
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">House Cleaning</h3>
                      <p className="text-sm text-gray-600">There are many variations of passages of Lorem Ipsum available, but the majority have suffered..</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-3">
                    <img 
                      src="https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" 
                      alt="Car cleaning"
                      className="w-16 h-16 rounded object-cover"
                    />
                    <div>
                      <h3 className="font-bold text-gray-900 mb-2">Car Cleaning</h3>
                      <p className="text-sm text-gray-600">There are many variations of passages of Lorem Ipsum available, but the majority have suffered..</p>
                    </div>
                  </div>
                </div>
                
                <div className="text-center mt-6">
                  <p className="text-sm text-gray-600 italic">If you want to see all the services <a href="#" className="text-blue-600 underline">View All</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Best Cleaning Service Section */}
      <section className="py-20 bg-cover bg-center relative"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80')`
        }}>
        <div className="absolute inset-0 bg-black/60"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="mb-12">
            <div className="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center mx-auto mb-8">
              <div className="w-0 h-0 border-l-[16px] border-l-white border-t-[12px] border-t-transparent border-b-[12px] border-b-transparent ml-1"></div>
            </div>
            
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-12">
              Best Cleaning Service in Homen
              <span className="block">Great Since 1989</span>
            </h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">House Cleaning</h3>
              <p className="text-sm text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
            
            <div className="bg-blue-600 p-6 rounded-lg text-center text-white">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-bold mb-2">Indoor Cleaning</h3>
              <p className="text-sm text-blue-100">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
            
            <div className="bg-white p-6 rounded-lg text-center">
              <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Bathroom Cleaning</h3>
              <p className="text-sm text-gray-600">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
            
            <div className="bg-blue-600 p-6 rounded-lg text-center text-white">
              <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center mx-auto mb-4">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-bold mb-2">Residential Cleaning</h3>
              <p className="text-sm text-blue-100">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-gradient-to-r from-green-400 to-yellow-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
              <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="h-8 w-8 text-white" />
              </div>
              <div className="text-4xl font-bold text-white mb-2">{stats.projectsCompleted.toLocaleString()}</div>
              <div className="text-white/90 font-medium">Projects Completed</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
              <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-white" />
              </div>
              <div className="text-4xl font-bold text-white mb-2">{stats.professionalTeams}+</div>
              <div className="text-white/90 font-medium">Professional Teams</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
              <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-white" />
              </div>
              <div className="text-4xl font-bold text-white mb-2">{stats.satisfiedCustomers}K</div>
              <div className="text-white/90 font-medium">Satisfied Customers</div>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-8 border border-white/20">
              <div className="w-16 h-16 bg-white/20 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-white" />
              </div>
              <div className="text-4xl font-bold text-white mb-2">{stats.awards}+</div>
              <div className="text-white/90 font-medium">Honorable Awards</div>
            </div>
          </div>
        </div>
      </section>

      {/* Recent Works Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="text-blue-600 font-medium uppercase tracking-wide mb-2">WORKS</div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Recent Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                  alt="Floor Cleaning"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute bottom-4 right-4 bg-orange-500 p-2 rounded">
                  <ArrowRight className="h-4 w-4 text-white" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">Floor Cleaning</h3>
                <p className="text-gray-600 text-sm">
                  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of...
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                  alt="Villa Cleaning"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute bottom-4 right-4 bg-orange-500 p-2 rounded">
                  <ArrowRight className="h-4 w-4 text-white" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">Villa Cleaning</h3>
                <p className="text-gray-600 text-sm">
                  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of...
                </p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="relative">
                <img 
                  src="https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                  alt="Hospital Cleaning"
                  className="w-full h-48 object-cover"
                />
                <div className="absolute bottom-4 right-4 bg-orange-500 p-2 rounded">
                  <ArrowRight className="h-4 w-4 text-white" />
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">Hospital Cleaning</h3>
                <p className="text-gray-600 text-sm">
                  It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of...
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-center mt-8 space-x-4">
            <button className="w-12 h-12 border-2 border-blue-600 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-600 hover:text-white transition-colors">
              <ArrowRight className="h-4 w-4 transform rotate-180" />
            </button>
            <button className="w-12 h-12 border-2 border-blue-600 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-600 hover:text-white transition-colors">
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Why Choose Us & Contact Form Section */}
      <section className="py-20 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-20 w-32 h-32 bg-white rounded-full animate-pulse"></div>
          <div className="absolute bottom-20 right-20 w-24 h-24 bg-orange-400 rounded-full animate-bounce"></div>
          <div className="absolute top-1/2 right-10 w-16 h-16 bg-red-300 rounded-full"></div>
        </div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-16 items-start">
            <div className="text-white">
              <h2 className="text-4xl lg:text-5xl font-bold mb-8 text-white">Why Choose Us</h2>
              <p className="text-blue-100 mb-8 text-lg leading-relaxed">
                We are Qatar's premier cleaning service with over 20 years of experience delivering exceptional results
              </p>
              
              <div className="space-y-8">
                <div className="flex items-start space-x-4 bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                  <div className="w-14 h-14 bg-orange-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Award className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-orange-300 mb-3">Top-Rated Company</h3>
                    <p className="text-blue-100 leading-relaxed">Consistently rated #1 cleaning service in Qatar with over 10,000 satisfied customers</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4 bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                  <div className="w-14 h-14 bg-orange-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Shield className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-orange-300 mb-3">Superior Quality</h3>
                    <p className="text-blue-100 leading-relaxed">Professional trained staff using eco-friendly products and latest cleaning technology</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4 bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20">
                  <div className="w-14 h-14 bg-orange-500 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Star className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-orange-300 mb-3">Award Winner</h3>
                    <p className="text-blue-100 leading-relaxed">Multiple industry awards for excellence in service quality and customer satisfaction</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-2xl p-8 shadow-2xl border border-gray-100">
              <h3 className="text-3xl font-bold text-gray-900 mb-3">Request a Proposal</h3>
              <p className="text-gray-600 mb-8 text-lg">Fill Out Our Form & We'll be in touch Shortly</p>
              
              <form className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Name</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                    <input 
                      type="email" 
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                      placeholder="your.email@example.com"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Phone</label>
                    <input 
                      type="tel" 
                      className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                      placeholder="+974 XXXX XXXX"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Service Type</label>
                    <select className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 bg-white">
                      <option>Select Service Type...</option>
                      <option>House Cleaning</option>
                      <option>Office Cleaning</option>
                      <option>Deep Cleaning</option>
                      <option>Carpet Cleaning</option>
                      <option>Window Cleaning</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Message</label>
                  <textarea 
                    rows="4" 
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-none"
                    placeholder="Tell us about your cleaning requirements..."
                  ></textarea>
                </div>
                
                <button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-4 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  Send Request
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="text-blue-600 font-medium uppercase tracking-wide mb-2">FEEDBACK</div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">What They're Talking About Comapany ?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-white rounded-lg p-8 shadow-lg relative">
              <div className="flex items-start space-x-4">
                <div className="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
                  M
                </div>
                <div className="flex-1">
                  <div className="absolute top-4 right-4 text-6xl text-orange-500 opacity-20">"</div>
                  <p className="text-gray-600 mb-4 italic">
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into...
                  </p>
                  <div className="flex text-yellow-400 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <div>
                    <div className="font-bold text-blue-600">Marry Delicate</div>
                    <div className="text-sm text-gray-500">CUSTOMER</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-8 shadow-lg relative">
              <div className="flex items-start space-x-4">
                <div className="w-20 h-20 bg-orange-500 rounded-full flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
                  B
                </div>
                <div className="flex-1">
                  <div className="absolute top-4 right-4 text-6xl text-orange-500 opacity-20">"</div>
                  <p className="text-gray-600 mb-4 italic">
                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into...
                  </p>
                  <div className="flex text-yellow-400 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <div>
                    <div className="font-bold text-blue-600">Benjamin</div>
                    <div className="text-sm text-gray-500">CUSTOMER</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-center mt-8 space-x-4">
            <button className="w-12 h-12 border-2 border-blue-600 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-600 hover:text-white transition-colors">
              <ArrowRight className="h-4 w-4 transform rotate-180" />
            </button>
            <button className="w-12 h-12 border-2 border-blue-600 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-600 hover:text-white transition-colors">
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Blog Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="text-blue-600 font-medium uppercase tracking-wide mb-2">NEWS & BLOGS</div>
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Exploring The Latest Articles</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Blog post"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <span className="bg-green-100 text-green-600 px-2 py-1 rounded text-xs mr-3">Cleanmac</span>
                  <span>May 28, 2025</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">It was popularised in the 1960s with the release of Letraset</h3>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Blog post"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <span className="bg-green-100 text-green-600 px-2 py-1 rounded text-xs mr-3">Cleanmac</span>
                  <span>May 28, 2025</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">It has survived not only five centuries, but also the leap into...</h3>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1581578731548-c64695cc6952?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80"
                alt="Blog post"
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center text-sm text-gray-500 mb-3">
                  <span className="bg-green-100 text-green-600 px-2 py-1 rounded text-xs mr-3">Cleanmac</span>
                  <span>May 28, 2025</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Many desktop publishing packages and web page editors now</h3>
              </div>
            </div>
          </div>

          <div className="flex justify-center mt-8 space-x-4">
            <button className="w-12 h-12 border-2 border-blue-600 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-600 hover:text-white transition-colors">
              <ArrowRight className="h-4 w-4 transform rotate-180" />
            </button>
            <button className="w-12 h-12 border-2 border-blue-600 rounded-full flex items-center justify-center text-blue-600 hover:bg-blue-600 hover:text-white transition-colors">
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}