import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check } from "lucide-react";

export default function PricingCard({ plan }) {
  return (
    <Card className={`pricing-card ${plan.popular ? 'bg-blue-500 scale-105' : 'bg-white'} rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300 relative`}>
      {plan.popular && (
        <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
          <span className="bg-yellow-500 text-gray-900 px-6 py-2 rounded-full font-bold text-sm">
            MOST POPULAR
          </span>
        </div>
      )}
      <CardContent className="p-8">
        <div className="text-center mb-8">
          <h3 className={`text-2xl font-bold mb-2 ${plan.popular ? 'text-white' : 'text-gray-900'}`}>
            {plan.name}
          </h3>
          <div className={`text-5xl font-bold mb-2 ${plan.popular ? 'text-yellow-400' : 'text-blue-500'}`}>
            ${plan.price}
          </div>
          <p className={plan.popular ? 'text-gray-200' : 'text-gray-600'}>per session</p>
        </div>
        <ul className={`space-y-4 mb-8 ${plan.popular ? 'text-white' : 'text-gray-900'}`}>
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-center">
              <Check className={`h-5 w-5 mr-3 ${plan.popular ? 'text-yellow-400' : 'text-green-500'}`} />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        <Link href="/book">
          <Button className={`w-full py-4 rounded-xl font-bold transition-colors duration-300 ${
            plan.popular 
              ? 'bg-yellow-500 hover:bg-yellow-600 text-gray-900' 
              : 'bg-gray-200 hover:bg-gray-300 text-gray-900'
          }`}>
            Choose Plan
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
