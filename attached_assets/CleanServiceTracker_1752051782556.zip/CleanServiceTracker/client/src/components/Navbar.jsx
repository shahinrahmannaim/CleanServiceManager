import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Menu, X, User, LogOut, ChevronDown, Phone, Mail, Facebook, Twitter, Instagram, Linkedin, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { authService } from "@/lib/auth.js";
import logoImage from "@assets/WhatsApp Image 2025-06-23 at 09.05.23_1750847082310.jpeg";
import Login from "@/pages/Login";
import Register from "@/pages/Register";

export default function Navbar() {
  const [location, navigate] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState(authService.getStoredUser());

  useEffect(() => {
    const checkUser = async () => {
      try {
        const currentUser = await authService.getCurrentUser();
        setUser(currentUser);
      } catch (error) {
        console.error('Auth check failed:', error);
        setUser(null);
      }
    };
    checkUser();
  }, []);

  // Listen for authentication changes
  useEffect(() => {
    const handleAuthChange = () => {
      const storedUser = authService.getStoredUser();
      setUser(storedUser);
    };

    // Listen for custom auth events
    window.addEventListener('auth-change', handleAuthChange);
    
    return () => {
      window.removeEventListener('auth-change', handleAuthChange);
    };
  }, []);
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const { toast } = useToast();

  const handleLogout = async () => {
    try {
      await authService.logout();
      setUser(null);
      navigate("/");
      toast({
        title: "Goodbye!",
        description: "You have been logged out successfully.",
      });
    } catch (error) {
      console.error("Logout failed:", error);
      // Clear user state even if logout request fails
      setUser(null);
      navigate("/");
      toast({
        title: "Logged out",
        description: "You have been logged out.",
      });
    }
  };

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/services", label: "Services" },
    { href: "/providers", label: "Providers" },
    { href: "/contact", label: "Contact Us" },
    { href: "/blog", label: "Blog" }
  ];

  return (
    <>
      {/* Top Contact Bar */}
      <div className="bg-blue-600 text-white py-2 text-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <div className="flex items-center">
              <Phone className="h-4 w-4 mr-2" />
              <span>+1 (212) 595-1962</span>
            </div>
            <div className="flex items-center">
              <Mail className="h-4 w-4 mr-2" />
              <span>info@example.com</span>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Facebook className="h-4 w-4 hover:text-blue-300 cursor-pointer" />
            <Twitter className="h-4 w-4 hover:text-blue-300 cursor-pointer" />
            <Linkedin className="h-4 w-4 hover:text-blue-300 cursor-pointer" />
            <Instagram className="h-4 w-4 hover:text-blue-300 cursor-pointer" />
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link href="/" className="flex items-center">
              <img 
                src={logoImage} 
                alt="Panaroma Cleaning Services" 
                className="h-20 w-auto object-contain"
              />
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`text-gray-900 font-medium transition-colors duration-200 hover:text-blue-600 ${
                    location === item.href ? "text-blue-600 font-bold" : ""
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </div>

            {/* Search and Auth */}
            <div className="hidden md:flex items-center space-x-4">
              <Link href="/services">
                <Button variant="ghost" size="sm">
                  <Search className="h-4 w-4" />
                </Button>
              </Link>

              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center space-x-2">
                      <User className="h-5 w-5" />
                      <span>{user.username}</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => navigate("/profile")}>
                      <User className="h-4 w-4 mr-2" />
                      Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/dashboard")}>
                      <User className="h-4 w-4 mr-2" />
                      Dashboard
                    </DropdownMenuItem>
                    {user.role === 'admin' && (
                      <DropdownMenuItem onClick={() => navigate("/admin")}>
                        <Shield className="h-4 w-4 mr-2" />
                        Admin Panel
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center space-x-2">
                      <User className="h-5 w-5" />
                      <span>Account</span>
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setShowLoginModal(true)}>
                      Login
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => setShowRegisterModal(true)}>
                      Join Us
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                variant="ghost"
                size="sm"
                className="text-gray-900"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden bg-white border-t border-gray-200">
              <div className="px-2 pt-2 pb-3 space-y-1">
                {navItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`block px-3 py-2 text-base font-medium rounded-md transition-colors duration-200 ${
                      location === item.href
                        ? "text-blue-600 bg-blue-50 font-bold"
                        : "text-gray-900 hover:text-blue-600 hover:bg-gray-50"
                    }`}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.label}
                  </Link>
                ))}
                
                {/* Mobile Auth Buttons */}
                <div className="pt-4 border-t border-gray-200">
                  {user ? (
                    <div className="space-y-2">
                      <div className="flex items-center px-3 py-2">
                        <User className="h-5 w-5 mr-2" />
                        <span className="text-sm font-medium">{user.username}</span>
                      </div>
                      <Button
                        onClick={() => {
                          navigate("/profile");
                          setIsMenuOpen(false);
                        }}
                        variant="ghost"
                        className="w-full justify-start text-gray-900 hover:text-blue-600"
                      >
                        <User className="h-4 w-4 mr-2" />
                        Profile
                      </Button>
                      <Button
                        onClick={() => {
                          navigate("/dashboard");
                          setIsMenuOpen(false);
                        }}
                        variant="ghost"
                        className="w-full justify-start text-gray-900 hover:text-blue-600"
                      >
                        <User className="h-4 w-4 mr-2" />
                        Dashboard
                      </Button>
                      <Button
                        onClick={() => {
                          handleLogout();
                          setIsMenuOpen(false);
                        }}
                        variant="ghost"
                        className="w-full justify-start text-red-600 hover:text-red-700"
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        Logout
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Button
                        onClick={() => {
                          setShowLoginModal(true);
                          setIsMenuOpen(false);
                        }}
                        variant="ghost"
                        className="w-full justify-start text-gray-900 hover:text-blue-600"
                      >
                        Login
                      </Button>
                      <Button
                        onClick={() => {
                          setShowRegisterModal(true);
                          setIsMenuOpen(false);
                        }}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        Join Us
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Login Modal */}
      <Dialog open={showLoginModal} onOpenChange={setShowLoginModal}>
        <DialogContent className="sm:max-w-md bg-white/95 backdrop-blur-sm" aria-describedby="login-description">
          <DialogTitle>Login to your account</DialogTitle>
          <div id="login-description" className="sr-only">Sign in to your Panaroma account to access your bookings and services</div>
          <Login onSuccess={async () => {
            setShowLoginModal(false);
            // Get the updated user from auth service
            const currentUser = await authService.getCurrentUser();
            setUser(currentUser);
            toast({
              title: "Welcome back!",
              description: "You have been logged in successfully.",
            });
          }} />
        </DialogContent>
      </Dialog>

      {/* Register Modal */}
      <Dialog open={showRegisterModal} onOpenChange={setShowRegisterModal}>
        <DialogContent className="sm:max-w-md bg-white/95 backdrop-blur-sm" aria-describedby="register-description">
          <DialogTitle>Create new account</DialogTitle>
          <div id="register-description" className="sr-only">Create your Panaroma account to access our cleaning services</div>
          <Register onSuccess={() => {
            setShowRegisterModal(false);
            setShowLoginModal(true);
            toast({
              title: "Registration successful!",
              description: "Please login with your new credentials.",
            });
          }} />
        </DialogContent>
      </Dialog>
    </>
  );
}