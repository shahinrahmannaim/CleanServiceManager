import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  UserCheck, 
  Clock, 
  DollarSign, 
  Settings, 
  BarChart3,
  FileText,
  ChevronLeft,
  ChevronRight
} from "lucide-react";

export default function AdminSidebar({ activeTab, setActiveTab, collapsed, setCollapsed }) {
  const sidebarItems = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "users", label: "User Management", icon: Users },
    { id: "bookings", label: "Bookings", icon: Calendar },
    { id: "providers", label: "Service Providers", icon: UserCheck },
    { id: "employees", label: "Employee Management", icon: Users },
    { id: "timetracking", label: "Time Tracking", icon: Clock },
    { id: "invoices", label: "Invoices & Payments", icon: DollarSign },
    { id: "services", label: "Service Management", icon: Settings },
    { id: "analytics", label: "Analytics", icon: BarChart3 }
  ];

  return (
    <div className={`${collapsed ? 'w-16' : 'w-64'} bg-white shadow-lg border-r border-gray-200 transition-all duration-300 ease-in-out`}>
      {/* Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
        {!collapsed && <h1 className="text-xl font-bold text-gray-900">Panaroma Admin</h1>}
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setCollapsed(!collapsed)}
          className="ml-auto"
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </Button>
      </div>
      
      {/* Navigation */}
      <nav className="mt-6 px-2">
        <div className="space-y-1">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center px-3 py-3 text-sm font-medium rounded-lg transition-all duration-200 ${
                  activeTab === item.id
                    ? 'bg-blue-100 text-blue-700 shadow-sm'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
                title={collapsed ? item.label : ''}
              >
                <Icon className={`h-5 w-5 ${collapsed ? 'mx-auto' : 'mr-3'}`} />
                {!collapsed && <span className="truncate">{item.label}</span>}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}