import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Search, Check, X, Eye, Star, MapPin, Phone, Mail } from 'lucide-react';

export default function ServiceProviderManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [viewingProvider, setViewingProvider] = useState(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch service providers
  const { data: providers = [], isLoading } = useQuery({
    queryKey: ['/api/admin/providers'],
    queryFn: () => apiRequest('GET', '/api/admin/providers').then(res => res.json())
  });

  // Approve provider mutation
  const approveProviderMutation = useMutation({
    mutationFn: (providerId) => apiRequest('POST', `/api/admin/providers/${providerId}/approve`),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/providers']);
      toast({
        title: 'Success',
        description: 'Provider approved successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to approve provider',
        variant: 'destructive'
      });
    }
  });

  // Reject provider mutation
  const rejectProviderMutation = useMutation({
    mutationFn: (providerId) => apiRequest('POST', `/api/admin/providers/${providerId}/reject`),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/providers']);
      toast({
        title: 'Success',
        description: 'Provider rejected successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to reject provider',
        variant: 'destructive'
      });
    }
  });

  // Filter providers
  const filteredProviders = providers.filter(provider => {
    const matchesSearch = provider.businessName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         provider.contactEmail?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         provider.services?.some(s => s.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = selectedStatus === 'all' || provider.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case 'pending': return 'secondary';
      case 'approved': return 'default';
      case 'rejected': return 'destructive';
      case 'suspended': return 'outline';
      default: return 'outline';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'text-yellow-600';
      case 'approved': return 'text-green-600';
      case 'rejected': return 'text-red-600';
      case 'suspended': return 'text-gray-600';
      default: return 'text-gray-600';
    }
  };

  const handleApprove = (providerId) => {
    if (window.confirm('Are you sure you want to approve this provider?')) {
      approveProviderMutation.mutate(providerId);
    }
  };

  const handleReject = (providerId) => {
    if (window.confirm('Are you sure you want to reject this provider?')) {
      rejectProviderMutation.mutate(providerId);
    }
  };

  const handleViewDetails = (provider) => {
    setViewingProvider(provider);
    setIsDetailModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Service Provider Management</CardTitle>
          <CardDescription>Manage service provider registrations and approvals</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search providers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Provider</TableHead>
                  <TableHead>Business Name</TableHead>
                  <TableHead>Services</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : filteredProviders.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">No providers found</TableCell>
                  </TableRow>
                ) : (
                  filteredProviders.map((provider) => (
                    <TableRow key={provider.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{provider.userName}</div>
                          <div className="text-sm text-gray-500">ID: {provider.id}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{provider.businessName}</div>
                          <div className="text-sm text-gray-500 flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {provider.serviceArea || 'Qatar'}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {provider.services?.slice(0, 2).map((service, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {service}
                            </Badge>
                          ))}
                          {provider.services?.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{provider.services.length - 2} more
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="flex items-center gap-1 text-sm">
                            <Mail className="h-3 w-3 text-gray-400" />
                            {provider.contactEmail}
                          </div>
                          <div className="flex items-center gap-1 text-sm text-gray-500">
                            <Phone className="h-3 w-3 text-gray-400" />
                            {provider.contactPhone || 'N/A'}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="font-medium">{provider.rating || '0.0'}</span>
                          <span className="text-sm text-gray-500">({provider.reviewCount || 0})</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(provider.status)} className={getStatusColor(provider.status)}>
                          {provider.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleViewDetails(provider)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          {provider.status === 'pending' && (
                            <>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleApprove(provider.id)}
                                className="text-green-600 hover:text-green-700"
                              >
                                <Check className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleReject(provider.id)}
                                className="text-red-600 hover:text-red-700"
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Provider Statistics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Providers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{providers.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approval</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {providers.filter(p => p.status === 'pending').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Approved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {providers.filter(p => p.status === 'approved').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active This Month</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">
              {providers.filter(p => p.status === 'approved' && p.isActive).length}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Provider Details Modal */}
      <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Provider Details</DialogTitle>
            <DialogDescription>Complete information about the service provider</DialogDescription>
          </DialogHeader>
          {viewingProvider && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Business Name</h4>
                  <p className="text-sm">{viewingProvider.businessName}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Contact Person</h4>
                  <p className="text-sm">{viewingProvider.userName}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Email</h4>
                  <p className="text-sm">{viewingProvider.contactEmail}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Phone</h4>
                  <p className="text-sm">{viewingProvider.contactPhone || 'N/A'}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Service Area</h4>
                  <p className="text-sm">{viewingProvider.serviceArea || 'Qatar'}</p>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Experience</h4>
                  <p className="text-sm">{viewingProvider.experience || 'N/A'}</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-sm text-gray-600 mb-2">Services Offered</h4>
                <div className="flex flex-wrap gap-2">
                  {viewingProvider.services?.map((service, index) => (
                    <Badge key={index} variant="outline">
                      {service}
                    </Badge>
                  )) || <span className="text-sm text-gray-500">No services listed</span>}
                </div>
              </div>
              
              <div>
                <h4 className="font-medium text-sm text-gray-600 mb-2">Description</h4>
                <p className="text-sm text-gray-700">{viewingProvider.description || 'No description provided'}</p>
              </div>
              
              <div className="flex items-center gap-4">
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Rating</h4>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm">{viewingProvider.rating || '0.0'}</span>
                    <span className="text-sm text-gray-500">({viewingProvider.reviewCount || 0} reviews)</span>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-sm text-gray-600">Status</h4>
                  <Badge variant={getStatusBadgeVariant(viewingProvider.status)} className={getStatusColor(viewingProvider.status)}>
                    {viewingProvider.status}
                  </Badge>
                </div>
              </div>
              
              {viewingProvider.status === 'pending' && (
                <div className="flex justify-end gap-2 pt-4 border-t">
                  <Button
                    variant="outline"
                    onClick={() => handleReject(viewingProvider.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Reject
                  </Button>
                  <Button
                    onClick={() => handleApprove(viewingProvider.id)}
                    className="text-white bg-green-600 hover:bg-green-700"
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Approve
                  </Button>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}