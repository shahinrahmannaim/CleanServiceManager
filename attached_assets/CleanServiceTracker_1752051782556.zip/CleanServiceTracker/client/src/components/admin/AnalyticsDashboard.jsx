import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Calendar, TrendingUp, TrendingDown, Users, DollarSign, Clock, Star, BarChart3 } from 'lucide-react';

export default function AnalyticsDashboard() {
  const [dateRange, setDateRange] = useState('30d');
  const [selectedEmployee, setSelectedEmployee] = useState('all');
  const [selectedService, setSelectedService] = useState('all');

  // Fetch analytics data
  const { data: analytics = {}, isLoading } = useQuery({
    queryKey: ['/api/admin/analytics', dateRange, selectedEmployee, selectedService],
    queryFn: () => apiRequest('GET', `/api/admin/analytics?range=${dateRange}&employee=${selectedEmployee}&service=${selectedService}`).then(res => res.json())
  });

  // Fetch employees for filter
  const { data: employees = [] } = useQuery({
    queryKey: ['/api/admin/employees'],
    queryFn: () => apiRequest('GET', '/api/admin/employees').then(res => res.json())
  });

  // Fetch services for filter
  const { data: services = [] } = useQuery({
    queryKey: ['/api/admin/services'],
    queryFn: () => apiRequest('GET', '/api/admin/services').then(res => res.json())
  });

  const getPercentageChange = (current, previous) => {
    if (!previous || previous === 0) return 0;
    return ((current - previous) / previous * 100).toFixed(1);
  };

  const formatCurrency = (amount) => {
    return `QAR ${parseFloat(amount || 0).toLocaleString()}`;
  };

  const StatCard = ({ title, value, change, icon: Icon, trend }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {change !== undefined && (
          <p className="text-xs text-muted-foreground flex items-center gap-1">
            {trend === 'up' ? (
              <TrendingUp className="h-3 w-3 text-green-600" />
            ) : trend === 'down' ? (
              <TrendingDown className="h-3 w-3 text-red-600" />
            ) : null}
            <span className={trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : ''}>
              {change > 0 ? '+' : ''}{change}%
            </span>
            <span>from last period</span>
          </p>
        )}
      </CardContent>
    </Card>
  );

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Analytics Dashboard</CardTitle>
          <CardDescription>Comprehensive insights and performance metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select period" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 3 months</SelectItem>
                <SelectItem value="1y">Last year</SelectItem>
              </SelectContent>
            </Select>
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by employee" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Employees</SelectItem>
                {employees.map(employee => (
                  <SelectItem key={employee.id} value={employee.id.toString()}>
                    {employee.userName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedService} onValueChange={setSelectedService}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by service" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Services</SelectItem>
                {services.map(service => (
                  <SelectItem key={service.id} value={service.id.toString()}>
                    {service.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Bookings"
          value={analytics.totalBookings || 0}
          change={getPercentageChange(analytics.totalBookings, analytics.previousBookings)}
          trend={analytics.totalBookings > analytics.previousBookings ? 'up' : 'down'}
          icon={Calendar}
        />
        <StatCard
          title="Completed Services"
          value={analytics.completedServices || 0}
          change={getPercentageChange(analytics.completedServices, analytics.previousCompleted)}
          trend={analytics.completedServices > analytics.previousCompleted ? 'up' : 'down'}
          icon={Users}
        />
        <StatCard
          title="Total Revenue"
          value={formatCurrency(analytics.totalRevenue)}
          change={getPercentageChange(analytics.totalRevenue, analytics.previousRevenue)}
          trend={analytics.totalRevenue > analytics.previousRevenue ? 'up' : 'down'}
          icon={DollarSign}
        />
        <StatCard
          title="Hours Worked"
          value={`${analytics.totalHours || 0}h`}
          change={getPercentageChange(analytics.totalHours, analytics.previousHours)}
          trend={analytics.totalHours > analytics.previousHours ? 'up' : 'down'}
          icon={Clock}
        />
      </div>

      {/* Charts and Detailed Analytics */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Booking Trends */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Booking Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.bookingTrends?.map((trend, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="text-sm text-gray-600">{trend.date}</div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm font-medium">{trend.bookings}</div>
                    <div 
                      className="h-2 bg-blue-200 rounded-full"
                      style={{ 
                        width: `${Math.max(trend.bookings / Math.max(...(analytics.bookingTrends?.map(t => t.bookings) || [1])) * 100, 5)}px`,
                        minWidth: '20px'
                      }}
                    >
                      <div 
                        className="h-2 bg-blue-600 rounded-full"
                        style={{ width: '100%' }}
                      ></div>
                    </div>
                  </div>
                </div>
              )) || <div className="text-sm text-gray-500">No trend data available</div>}
            </div>
          </CardContent>
        </Card>

        {/* Revenue by Service */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Revenue by Service
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.revenueByService?.slice(0, 5).map((service, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="text-sm text-gray-600 truncate max-w-[120px]">{service.name}</div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm font-medium">{formatCurrency(service.revenue)}</div>
                    <div 
                      className="h-2 bg-green-200 rounded-full"
                      style={{ 
                        width: `${Math.max(service.revenue / Math.max(...(analytics.revenueByService?.map(s => s.revenue) || [1])) * 100, 5)}px`,
                        minWidth: '20px'
                      }}
                    >
                      <div 
                        className="h-2 bg-green-600 rounded-full"
                        style={{ width: '100%' }}
                      ></div>
                    </div>
                  </div>
                </div>
              )) || <div className="text-sm text-gray-500">No revenue data available</div>}
            </div>
          </CardContent>
        </Card>

        {/* Employee Performance */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.topPerformers?.slice(0, 5).map((employee, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                      index === 0 ? 'bg-yellow-100 text-yellow-800' :
                      index === 1 ? 'bg-gray-100 text-gray-800' :
                      index === 2 ? 'bg-orange-100 text-orange-800' :
                      'bg-blue-100 text-blue-800'
                    }`}>
                      {index + 1}
                    </div>
                    <div>
                      <div className="text-sm font-medium">{employee.name}</div>
                      <div className="text-xs text-gray-500">{employee.completedJobs} jobs</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-3 w-3 text-yellow-400 fill-current" />
                    <span className="text-sm font-medium">{employee.rating}</span>
                  </div>
                </div>
              )) || <div className="text-sm text-gray-500">No performance data available</div>}
            </div>
          </CardContent>
        </Card>

        {/* Service Popularity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Popular Services
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analytics.popularServices?.slice(0, 5).map((service, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="text-sm text-gray-600 truncate max-w-[120px]">{service.name}</div>
                  <div className="flex items-center gap-2">
                    <div className="text-sm font-medium">{service.bookings} bookings</div>
                    <div 
                      className="h-2 bg-purple-200 rounded-full"
                      style={{ 
                        width: `${Math.max(service.bookings / Math.max(...(analytics.popularServices?.map(s => s.bookings) || [1])) * 100, 5)}px`,
                        minWidth: '20px'
                      }}
                    >
                      <div 
                        className="h-2 bg-purple-600 rounded-full"
                        style={{ width: '100%' }}
                      ></div>
                    </div>
                  </div>
                </div>
              )) || <div className="text-sm text-gray-500">No popularity data available</div>}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Customer Satisfaction</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <div className="text-3xl font-bold">{analytics.avgRating || '0.0'}</div>
              <Star className="h-6 w-6 text-yellow-400 fill-current" />
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Based on {analytics.totalReviews || 0} reviews
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Completion Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {analytics.completionRate || 0}%
            </div>
            <p className="text-sm text-gray-600 mt-2">
              {analytics.completedServices || 0} of {analytics.totalBookings || 0} bookings completed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Average Job Duration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {analytics.avgJobDuration || 0}h
            </div>
            <p className="text-sm text-gray-600 mt-2">
              Average time per completed job
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}