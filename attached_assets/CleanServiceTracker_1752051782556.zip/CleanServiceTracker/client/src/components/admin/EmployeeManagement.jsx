import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Search, Plus, Edit, Trash2, Clock, Star, UserCheck } from 'lucide-react';

export default function EmployeeManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProvider, setSelectedProvider] = useState('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState(null);
  const [newEmployee, setNewEmployee] = useState({
    userId: '',
    providerId: '',
    position: '',
    hourlyRate: '',
    skills: '',
    isActive: true
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch employees
  const { data: employees = [], isLoading } = useQuery({
    queryKey: ['/api/admin/employees'],
    queryFn: () => apiRequest('GET', '/api/admin/employees').then(res => res.json())
  });

  // Fetch users for dropdown
  const { data: users = [] } = useQuery({
    queryKey: ['/api/admin/users'],
    queryFn: () => apiRequest('GET', '/api/admin/users').then(res => res.json())
  });

  // Fetch providers for dropdown
  const { data: providers = [] } = useQuery({
    queryKey: ['/api/admin/providers'],
    queryFn: () => apiRequest('GET', '/api/admin/providers').then(res => res.json())
  });

  // Create employee mutation
  const createEmployeeMutation = useMutation({
    mutationFn: (employeeData) => apiRequest('POST', '/api/admin/employees', employeeData),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/employees']);
      setIsCreateModalOpen(false);
      setNewEmployee({
        userId: '',
        providerId: '',
        position: '',
        hourlyRate: '',
        skills: '',
        isActive: true
      });
      toast({
        title: 'Success',
        description: 'Employee created successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create employee',
        variant: 'destructive'
      });
    }
  });

  // Update employee mutation
  const updateEmployeeMutation = useMutation({
    mutationFn: ({ id, ...employeeData }) => apiRequest('PUT', `/api/admin/employees/${id}`, employeeData),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/employees']);
      setIsEditModalOpen(false);
      setEditingEmployee(null);
      toast({
        title: 'Success',
        description: 'Employee updated successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update employee',
        variant: 'destructive'
      });
    }
  });

  // Delete employee mutation
  const deleteEmployeeMutation = useMutation({
    mutationFn: (employeeId) => apiRequest('DELETE', `/api/admin/employees/${employeeId}`),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/employees']);
      toast({
        title: 'Success',
        description: 'Employee deleted successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete employee',
        variant: 'destructive'
      });
    }
  });

  // Filter employees
  const filteredEmployees = employees.filter(employee => {
    const matchesSearch = employee.userName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.position?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         employee.skills?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesProvider = selectedProvider === 'all' || employee.providerId?.toString() === selectedProvider;
    return matchesSearch && matchesProvider;
  });

  const handleCreateEmployee = () => {
    createEmployeeMutation.mutate({
      ...newEmployee,
      hourlyRate: parseFloat(newEmployee.hourlyRate),
      skills: newEmployee.skills.split(',').map(s => s.trim())
    });
  };

  const handleEditEmployee = (employee) => {
    setEditingEmployee({
      ...employee,
      skills: Array.isArray(employee.skills) ? employee.skills.join(', ') : employee.skills
    });
    setIsEditModalOpen(true);
  };

  const handleUpdateEmployee = () => {
    updateEmployeeMutation.mutate({
      ...editingEmployee,
      hourlyRate: parseFloat(editingEmployee.hourlyRate),
      skills: editingEmployee.skills.split(',').map(s => s.trim())
    });
  };

  const handleDeleteEmployee = (employeeId) => {
    if (window.confirm('Are you sure you want to delete this employee?')) {
      deleteEmployeeMutation.mutate(employeeId);
    }
  };

  const availableUsers = users.filter(user => 
    user.role === 'employee' && !employees.some(emp => emp.userId === user.id)
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Employee Management</CardTitle>
          <CardDescription>Manage employees and their assignments to service providers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search employees..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedProvider} onValueChange={setSelectedProvider}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by provider" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Providers</SelectItem>
                {providers.map(provider => (
                  <SelectItem key={provider.id} value={provider.id.toString()}>
                    {provider.businessName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Employee
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Create New Employee</DialogTitle>
                  <DialogDescription>Assign a user as an employee to a service provider</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="user" className="text-right">User</Label>
                    <Select value={newEmployee.userId} onValueChange={(value) => setNewEmployee({ ...newEmployee, userId: value })}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select user" />
                      </SelectTrigger>
                      <SelectContent>
                        {availableUsers.map(user => (
                          <SelectItem key={user.id} value={user.id.toString()}>
                            {user.username} ({user.email})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="provider" className="text-right">Provider</Label>
                    <Select value={newEmployee.providerId} onValueChange={(value) => setNewEmployee({ ...newEmployee, providerId: value })}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select provider" />
                      </SelectTrigger>
                      <SelectContent>
                        {providers.filter(p => p.status === 'approved').map(provider => (
                          <SelectItem key={provider.id} value={provider.id.toString()}>
                            {provider.businessName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="position" className="text-right">Position</Label>
                    <Input
                      id="position"
                      placeholder="e.g., Cleaner, Plumber"
                      value={newEmployee.position}
                      onChange={(e) => setNewEmployee({ ...newEmployee, position: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="hourlyRate" className="text-right">Hourly Rate (QAR)</Label>
                    <Input
                      id="hourlyRate"
                      type="number"
                      step="0.01"
                      placeholder="50.00"
                      value={newEmployee.hourlyRate}
                      onChange={(e) => setNewEmployee({ ...newEmployee, hourlyRate: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="skills" className="text-right">Skills</Label>
                    <Input
                      id="skills"
                      placeholder="Cleaning, Maintenance, Repair (comma-separated)"
                      value={newEmployee.skills}
                      onChange={(e) => setNewEmployee({ ...newEmployee, skills: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateEmployee} disabled={createEmployeeMutation.isPending}>
                    {createEmployeeMutation.isPending ? 'Creating...' : 'Create Employee'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead>Rate/Hour</TableHead>
                  <TableHead>Skills</TableHead>
                  <TableHead>Hours This Month</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : filteredEmployees.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center">No employees found</TableCell>
                  </TableRow>
                ) : (
                  filteredEmployees.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{employee.userName}</div>
                          <div className="text-sm text-gray-500">{employee.userEmail}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{employee.providerName}</div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{employee.position}</Badge>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">QAR {employee.hourlyRate}/hr</div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {(Array.isArray(employee.skills) ? employee.skills : employee.skills?.split(',') || [])
                            .slice(0, 2).map((skill, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {skill.trim()}
                            </Badge>
                          ))}
                          {(Array.isArray(employee.skills) ? employee.skills : employee.skills?.split(',') || []).length > 2 && (
                            <Badge variant="secondary" className="text-xs">
                              +{(Array.isArray(employee.skills) ? employee.skills : employee.skills?.split(',') || []).length - 2} more
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-gray-400" />
                          <span className="font-medium">{employee.hoursThisMonth || 0}h</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={employee.isActive ? 'default' : 'secondary'}>
                          {employee.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditEmployee(employee)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteEmployee(employee.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Employee Statistics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{employees.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Employees</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {employees.filter(emp => emp.isActive).length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Hours This Month</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {employees.reduce((total, emp) => total + (emp.hoursThisMonth || 0), 0)}h
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Performance</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {employees.length > 0 
                ? (employees.reduce((total, emp) => total + (emp.rating || 0), 0) / employees.length).toFixed(1)
                : '0.0'
              }
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Edit Employee Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Employee</DialogTitle>
            <DialogDescription>Update employee information</DialogDescription>
          </DialogHeader>
          {editingEmployee && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-provider" className="text-right">Provider</Label>
                <Select value={editingEmployee.providerId?.toString()} onValueChange={(value) => setEditingEmployee({ ...editingEmployee, providerId: parseInt(value) })}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {providers.filter(p => p.status === 'approved').map(provider => (
                      <SelectItem key={provider.id} value={provider.id.toString()}>
                        {provider.businessName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-position" className="text-right">Position</Label>
                <Input
                  id="edit-position"
                  value={editingEmployee.position}
                  onChange={(e) => setEditingEmployee({ ...editingEmployee, position: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-hourlyRate" className="text-right">Hourly Rate (QAR)</Label>
                <Input
                  id="edit-hourlyRate"
                  type="number"
                  step="0.01"
                  value={editingEmployee.hourlyRate}
                  onChange={(e) => setEditingEmployee({ ...editingEmployee, hourlyRate: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-skills" className="text-right">Skills</Label>
                <Input
                  id="edit-skills"
                  value={editingEmployee.skills}
                  onChange={(e) => setEditingEmployee({ ...editingEmployee, skills: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-status" className="text-right">Status</Label>
                <Select value={editingEmployee.isActive ? 'active' : 'inactive'} onValueChange={(value) => setEditingEmployee({ ...editingEmployee, isActive: value === 'active' })}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateEmployee} disabled={updateEmployeeMutation.isPending}>
              {updateEmployeeMutation.isPending ? 'Updating...' : 'Update Employee'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}