import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Search, Plus, Edit, Trash2, MessageCircle, Bot, Settings, BarChart3 } from 'lucide-react';

export default function ChatbotManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [editingResponse, setEditingResponse] = useState(null);
  const [newResponse, setNewResponse] = useState({
    question: '',
    answer: '',
    keywords: '',
    category: 'general',
    isActive: true
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch chatbot responses
  const { data: responses = [], isLoading } = useQuery({
    queryKey: ['/api/admin/chatbot/responses'],
    queryFn: () => apiRequest('GET', '/api/admin/chatbot/responses').then(res => res.json())
  });

  // Fetch chatbot settings
  const { data: settings = {}, isLoading: settingsLoading } = useQuery({
    queryKey: ['/api/admin/chatbot/settings'],
    queryFn: () => apiRequest('GET', '/api/admin/chatbot/settings').then(res => res.json())
  });

  // Fetch chatbot analytics
  const { data: analytics = {}, isLoading: analyticsLoading } = useQuery({
    queryKey: ['/api/admin/chatbot/analytics'],
    queryFn: () => apiRequest('GET', '/api/admin/chatbot/analytics').then(res => res.json())
  });

  // Create response mutation
  const createResponseMutation = useMutation({
    mutationFn: (responseData) => apiRequest('POST', '/api/admin/chatbot/responses', responseData),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/chatbot/responses']);
      setIsCreateModalOpen(false);
      setNewResponse({
        question: '',
        answer: '',
        keywords: '',
        category: 'general',
        isActive: true
      });
      toast({
        title: 'Success',
        description: 'Chatbot response created successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create response',
        variant: 'destructive'
      });
    }
  });

  // Update response mutation
  const updateResponseMutation = useMutation({
    mutationFn: ({ id, ...responseData }) => apiRequest('PUT', `/api/admin/chatbot/responses/${id}`, responseData),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/chatbot/responses']);
      setIsEditModalOpen(false);
      setEditingResponse(null);
      toast({
        title: 'Success',
        description: 'Chatbot response updated successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update response',
        variant: 'destructive'
      });
    }
  });

  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: (settingsData) => apiRequest('PUT', '/api/admin/chatbot/settings', settingsData),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/chatbot/settings']);
      setIsSettingsModalOpen(false);
      toast({
        title: 'Success',
        description: 'Chatbot settings updated successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update settings',
        variant: 'destructive'
      });
    }
  });

  // Delete response mutation
  const deleteResponseMutation = useMutation({
    mutationFn: (responseId) => apiRequest('DELETE', `/api/admin/chatbot/responses/${responseId}`),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/chatbot/responses']);
      toast({
        title: 'Success',
        description: 'Chatbot response deleted successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete response',
        variant: 'destructive'
      });
    }
  });

  // Filter responses
  const filteredResponses = responses.filter(response => {
    const matchesSearch = response.question?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         response.answer?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         response.keywords?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  const handleCreateResponse = () => {
    createResponseMutation.mutate({
      ...newResponse,
      keywords: newResponse.keywords.split(',').map(k => k.trim()).filter(k => k)
    });
  };

  const handleEditResponse = (response) => {
    setEditingResponse({
      ...response,
      keywords: Array.isArray(response.keywords) ? response.keywords.join(', ') : response.keywords
    });
    setIsEditModalOpen(true);
  };

  const handleUpdateResponse = () => {
    updateResponseMutation.mutate({
      ...editingResponse,
      keywords: editingResponse.keywords.split(',').map(k => k.trim()).filter(k => k)
    });
  };

  const handleDeleteResponse = (responseId) => {
    if (window.confirm('Are you sure you want to delete this response?')) {
      deleteResponseMutation.mutate(responseId);
    }
  };

  const categories = ['general', 'services', 'pricing', 'booking', 'support', 'hours'];

  return (
    <div className="space-y-6">
      {/* Chatbot Analytics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Conversations</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.totalConversations || 0}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Resolved Queries</CardTitle>
            <Bot className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{analytics.resolvedQueries || 0}</div>
            <p className="text-xs text-muted-foreground">
              {analytics.resolutionRate || 0}% resolution rate
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Responses</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{responses.filter(r => r.isActive).length}</div>
            <p className="text-xs text-muted-foreground">
              {responses.length} total responses
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics.avgResponseTime || '0.1'}s</div>
            <p className="text-xs text-muted-foreground">Average response time</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5" />
            Chatbot Management
          </CardTitle>
          <CardDescription>Manage chatbot responses and settings for customer support</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search responses..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Dialog open={isSettingsModalOpen} onOpenChange={setIsSettingsModalOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Chatbot Settings</DialogTitle>
                  <DialogDescription>Configure chatbot behavior and responses</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="enabled">Enable Chatbot</Label>
                    <Switch
                      id="enabled"
                      checked={settings.enabled || false}
                      onCheckedChange={(checked) => {
                        updateSettingsMutation.mutate({ ...settings, enabled: checked });
                      }}
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="welcome" className="text-right">Welcome Message</Label>
                    <Textarea
                      id="welcome"
                      value={settings.welcomeMessage || ''}
                      onChange={(e) => {
                        updateSettingsMutation.mutate({ ...settings, welcomeMessage: e.target.value });
                      }}
                      className="col-span-3"
                      placeholder="Hi! I'm here to help you with any questions about our cleaning services..."
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="fallback" className="text-right">Fallback Message</Label>
                    <Textarea
                      id="fallback"
                      value={settings.fallbackMessage || ''}
                      onChange={(e) => {
                        updateSettingsMutation.mutate({ ...settings, fallbackMessage: e.target.value });
                      }}
                      className="col-span-3"
                      placeholder="I'm sorry, I didn't understand that. Could you please rephrase your question?"
                    />
                  </div>
                </div>
              </DialogContent>
            </Dialog>
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Response
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Create New Response</DialogTitle>
                  <DialogDescription>Add a new automated response for the chatbot</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="question" className="text-right">Question</Label>
                    <Input
                      id="question"
                      placeholder="What are your operating hours?"
                      value={newResponse.question}
                      onChange={(e) => setNewResponse({ ...newResponse, question: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="answer" className="text-right">Answer</Label>
                    <Textarea
                      id="answer"
                      placeholder="We operate from 8 AM to 6 PM, Monday to Saturday..."
                      value={newResponse.answer}
                      onChange={(e) => setNewResponse({ ...newResponse, answer: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="keywords" className="text-right">Keywords</Label>
                    <Input
                      id="keywords"
                      placeholder="hours, time, open, schedule (comma-separated)"
                      value={newResponse.keywords}
                      onChange={(e) => setNewResponse({ ...newResponse, keywords: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="category" className="text-right">Category</Label>
                    <select
                      id="category"
                      value={newResponse.category}
                      onChange={(e) => setNewResponse({ ...newResponse, category: e.target.value })}
                      className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {categories.map(category => (
                        <option key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateResponse} disabled={createResponseMutation.isPending}>
                    {createResponseMutation.isPending ? 'Creating...' : 'Create Response'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Question</TableHead>
                  <TableHead>Answer</TableHead>
                  <TableHead>Keywords</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Usage</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : filteredResponses.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">No responses found</TableCell>
                  </TableRow>
                ) : (
                  filteredResponses.map((response) => (
                    <TableRow key={response.id}>
                      <TableCell>
                        <div className="max-w-[200px] truncate font-medium">{response.question}</div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-[250px] truncate text-sm text-gray-600">
                          {response.answer}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {(Array.isArray(response.keywords) ? response.keywords : response.keywords?.split(',') || [])
                            .slice(0, 2).map((keyword, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {keyword.trim()}
                            </Badge>
                          ))}
                          {(Array.isArray(response.keywords) ? response.keywords : response.keywords?.split(',') || []).length > 2 && (
                            <Badge variant="secondary" className="text-xs">
                              +{(Array.isArray(response.keywords) ? response.keywords : response.keywords?.split(',') || []).length - 2}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{response.category}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={response.isActive ? 'default' : 'secondary'}>
                          {response.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <span className="text-sm font-medium">{response.usageCount || 0}</span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditResponse(response)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteResponse(response.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Response Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Response</DialogTitle>
            <DialogDescription>Update chatbot response information</DialogDescription>
          </DialogHeader>
          {editingResponse && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-question" className="text-right">Question</Label>
                <Input
                  id="edit-question"
                  value={editingResponse.question}
                  onChange={(e) => setEditingResponse({ ...editingResponse, question: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-answer" className="text-right">Answer</Label>
                <Textarea
                  id="edit-answer"
                  value={editingResponse.answer}
                  onChange={(e) => setEditingResponse({ ...editingResponse, answer: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-keywords" className="text-right">Keywords</Label>
                <Input
                  id="edit-keywords"
                  value={editingResponse.keywords}
                  onChange={(e) => setEditingResponse({ ...editingResponse, keywords: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="edit-category" className="text-right">Category</Label>
                <select
                  id="edit-category"
                  value={editingResponse.category}
                  onChange={(e) => setEditingResponse({ ...editingResponse, category: e.target.value })}
                  className="col-span-3 flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  {categories.map(category => (
                    <option key={category} value={category}>
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2">
                <Switch
                  id="edit-status"
                  checked={editingResponse.isActive}
                  onCheckedChange={(checked) => setEditingResponse({ ...editingResponse, isActive: checked })}
                />
                <Label htmlFor="edit-status">Active</Label>
              </div>
            </div>
          )}
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setIsEditModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateResponse} disabled={updateResponseMutation.isPending}>
              {updateResponseMutation.isPending ? 'Updating...' : 'Update Response'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}