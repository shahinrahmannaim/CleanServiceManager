import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Search, Play, Pause, Square, Plus, Clock, Calendar, User } from 'lucide-react';

export default function TimeTracker() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEmployee, setSelectedEmployee] = useState('all');
  const [isManualEntryOpen, setIsManualEntryOpen] = useState(false);
  const [timer, setTimer] = useState({ isRunning: false, seconds: 0, startTime: null });
  const [activeEntry, setActiveEntry] = useState(null);
  const [manualEntry, setManualEntry] = useState({
    employeeId: '',
    bookingId: '',
    startTime: '',
    endTime: '',
    description: ''
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch time entries
  const { data: timeEntries = [], isLoading } = useQuery({
    queryKey: ['/api/admin/time-entries'],
    queryFn: () => apiRequest('GET', '/api/admin/time-entries').then(res => res.json())
  });

  // Fetch employees for dropdown
  const { data: employees = [] } = useQuery({
    queryKey: ['/api/admin/employees'],
    queryFn: () => apiRequest('GET', '/api/admin/employees').then(res => res.json())
  });

  // Fetch active bookings for dropdown
  const { data: bookings = [] } = useQuery({
    queryKey: ['/api/admin/bookings', 'active'],
    queryFn: () => apiRequest('GET', '/api/admin/bookings?status=confirmed,in_progress').then(res => res.json())
  });

  // Start timer mutation
  const startTimerMutation = useMutation({
    mutationFn: (data) => apiRequest('POST', '/api/admin/time-entries/start', data),
    onSuccess: (response) => {
      setActiveEntry(response);
      setTimer({
        isRunning: true,
        seconds: 0,
        startTime: new Date()
      });
      queryClient.invalidateQueries(['/api/admin/time-entries']);
      toast({
        title: 'Timer Started',
        description: 'Time tracking has begun for this task'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to start timer',
        variant: 'destructive'
      });
    }
  });

  // Stop timer mutation
  const stopTimerMutation = useMutation({
    mutationFn: (entryId) => apiRequest('PUT', `/api/admin/time-entries/${entryId}/stop`),
    onSuccess: () => {
      setActiveEntry(null);
      setTimer({
        isRunning: false,
        seconds: 0,
        startTime: null
      });
      queryClient.invalidateQueries(['/api/admin/time-entries']);
      toast({
        title: 'Timer Stopped',
        description: 'Time entry has been saved'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to stop timer',
        variant: 'destructive'
      });
    }
  });

  // Create manual entry mutation
  const createManualEntryMutation = useMutation({
    mutationFn: (entryData) => apiRequest('POST', '/api/admin/time-entries/manual', entryData),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/time-entries']);
      setIsManualEntryOpen(false);
      setManualEntry({
        employeeId: '',
        bookingId: '',
        startTime: '',
        endTime: '',
        description: ''
      });
      toast({
        title: 'Success',
        description: 'Manual time entry created successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create manual entry',
        variant: 'destructive'
      });
    }
  });

  // Timer effect
  useEffect(() => {
    let interval = null;
    if (timer.isRunning) {
      interval = setInterval(() => {
        setTimer(prev => ({
          ...prev,
          seconds: Math.floor((new Date() - prev.startTime) / 1000)
        }));
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timer.isRunning, timer.startTime]);

  // Filter time entries
  const filteredEntries = timeEntries.filter(entry => {
    const matchesSearch = entry.employeeName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.bookingService?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.description?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesEmployee = selectedEmployee === 'all' || entry.employeeId?.toString() === selectedEmployee;
    return matchesSearch && matchesEmployee;
  });

  const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const calculateDuration = (startTime, endTime) => {
    if (!startTime || !endTime) return '0:00';
    const start = new Date(startTime);
    const end = new Date(endTime);
    const diffInMinutes = Math.floor((end - start) / (1000 * 60));
    const hours = Math.floor(diffInMinutes / 60);
    const minutes = diffInMinutes % 60;
    return `${hours}:${minutes.toString().padStart(2, '0')}`;
  };

  const handleStartTimer = (employeeId, bookingId, description) => {
    startTimerMutation.mutate({
      employeeId,
      bookingId,
      description
    });
  };

  const handleStopTimer = () => {
    if (activeEntry) {
      stopTimerMutation.mutate(activeEntry.id);
    }
  };

  const handleCreateManualEntry = () => {
    createManualEntryMutation.mutate(manualEntry);
  };

  return (
    <div className="space-y-6">
      {/* Active Timer Card */}
      {timer.isRunning && activeEntry && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800 flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Active Timer
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-2xl font-mono font-bold text-green-700">
                  {formatTime(timer.seconds)}
                </div>
                <div className="text-sm text-green-600">
                  {activeEntry.employeeName} - {activeEntry.bookingService}
                </div>
              </div>
              <Button
                onClick={handleStopTimer}
                variant="destructive"
                className="flex items-center gap-2"
              >
                <Square className="h-4 w-4" />
                Stop Timer
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Time Tracker</CardTitle>
          <CardDescription>Track employee working hours and service time</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search time entries..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Filter by employee" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Employees</SelectItem>
                {employees.map(employee => (
                  <SelectItem key={employee.id} value={employee.id.toString()}>
                    {employee.userName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Dialog open={isManualEntryOpen} onOpenChange={setIsManualEntryOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Manual Entry
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[500px]">
                <DialogHeader>
                  <DialogTitle>Add Manual Time Entry</DialogTitle>
                  <DialogDescription>Create a time entry for past work</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="employee" className="text-right">Employee</Label>
                    <Select value={manualEntry.employeeId} onValueChange={(value) => setManualEntry({ ...manualEntry, employeeId: value })}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select employee" />
                      </SelectTrigger>
                      <SelectContent>
                        {employees.filter(emp => emp.isActive).map(employee => (
                          <SelectItem key={employee.id} value={employee.id.toString()}>
                            {employee.userName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="booking" className="text-right">Booking</Label>
                    <Select value={manualEntry.bookingId} onValueChange={(value) => setManualEntry({ ...manualEntry, bookingId: value })}>
                      <SelectTrigger className="col-span-3">
                        <SelectValue placeholder="Select booking" />
                      </SelectTrigger>
                      <SelectContent>
                        {bookings.map(booking => (
                          <SelectItem key={booking.id} value={booking.id.toString()}>
                            #{booking.id} - {booking.serviceName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="startTime" className="text-right">Start Time</Label>
                    <Input
                      id="startTime"
                      type="datetime-local"
                      value={manualEntry.startTime}
                      onChange={(e) => setManualEntry({ ...manualEntry, startTime: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="endTime" className="text-right">End Time</Label>
                    <Input
                      id="endTime"
                      type="datetime-local"
                      value={manualEntry.endTime}
                      onChange={(e) => setManualEntry({ ...manualEntry, endTime: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="description" className="text-right">Description</Label>
                    <Textarea
                      id="description"
                      placeholder="Describe the work performed"
                      value={manualEntry.description}
                      onChange={(e) => setManualEntry({ ...manualEntry, description: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsManualEntryOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateManualEntry} disabled={createManualEntryMutation.isPending}>
                    {createManualEntryMutation.isPending ? 'Creating...' : 'Create Entry'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Booking</TableHead>
                  <TableHead>Start Time</TableHead>
                  <TableHead>End Time</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : filteredEntries.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">No time entries found</TableCell>
                  </TableRow>
                ) : (
                  filteredEntries.map((entry) => (
                    <TableRow key={entry.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <User className="h-4 w-4 text-gray-400" />
                          <div>
                            <div className="font-medium">{entry.employeeName}</div>
                            <div className="text-sm text-gray-500">{entry.providerName}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">#{entry.bookingId}</div>
                          <div className="text-sm text-gray-500">{entry.bookingService}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <div className="text-sm">
                            {new Date(entry.startTime).toLocaleString()}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          {entry.endTime ? new Date(entry.endTime).toLocaleString() : 'Running...'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-gray-400" />
                          <span className="font-mono font-medium">
                            {entry.endTime ? calculateDuration(entry.startTime, entry.endTime) : formatTime(timer.seconds)}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="max-w-[200px] truncate text-sm">
                          {entry.description || 'No description'}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={entry.endTime ? 'default' : 'secondary'}>
                          {entry.endTime ? 'Completed' : 'In Progress'}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Time Statistics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Entries</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{timeEntries.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Timers</CardTitle>
            <Play className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {timeEntries.filter(entry => !entry.endTime).length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hours This Week</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {timeEntries
                .filter(entry => entry.endTime)
                .reduce((total, entry) => {
                  const duration = (new Date(entry.endTime) - new Date(entry.startTime)) / (1000 * 60 * 60);
                  return total + duration;
                }, 0)
                .toFixed(1)}h
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Session</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {timeEntries.filter(entry => entry.endTime).length > 0
                ? (timeEntries
                    .filter(entry => entry.endTime)
                    .reduce((total, entry) => {
                      const duration = (new Date(entry.endTime) - new Date(entry.startTime)) / (1000 * 60 * 60);
                      return total + duration;
                    }, 0) / timeEntries.filter(entry => entry.endTime).length)
                    .toFixed(1)
                : '0.0'
              }h
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}