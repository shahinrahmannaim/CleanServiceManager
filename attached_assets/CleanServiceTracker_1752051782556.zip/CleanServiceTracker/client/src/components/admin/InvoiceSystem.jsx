import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Search, Plus, Download, FileText, Calendar, DollarSign, CheckCircle, XCircle } from 'lucide-react';

export default function InvoiceSystem() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [newInvoice, setNewInvoice] = useState({
    providerId: '',
    bookingId: '',
    items: [{ description: '', hours: '', rate: '', amount: '' }],
    notes: ''
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch invoices
  const { data: invoices = [], isLoading } = useQuery({
    queryKey: ['/api/admin/invoices'],
    queryFn: () => apiRequest('GET', '/api/admin/invoices').then(res => res.json())
  });

  // Fetch providers for dropdown
  const { data: providers = [] } = useQuery({
    queryKey: ['/api/admin/providers'],
    queryFn: () => apiRequest('GET', '/api/admin/providers').then(res => res.json())
  });

  // Fetch completed bookings for dropdown
  const { data: bookings = [] } = useQuery({
    queryKey: ['/api/admin/bookings', 'completed'],
    queryFn: () => apiRequest('GET', '/api/admin/bookings?status=completed').then(res => res.json())
  });

  // Create invoice mutation
  const createInvoiceMutation = useMutation({
    mutationFn: (invoiceData) => apiRequest('POST', '/api/admin/invoices', invoiceData),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/invoices']);
      setIsCreateModalOpen(false);
      resetNewInvoice();
      toast({
        title: 'Success',
        description: 'Invoice created successfully'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to create invoice',
        variant: 'destructive'
      });
    }
  });

  // Mark invoice as paid mutation
  const markPaidMutation = useMutation({
    mutationFn: (invoiceId) => apiRequest('PUT', `/api/admin/invoices/${invoiceId}/mark-paid`),
    onSuccess: () => {
      queryClient.invalidateQueries(['/api/admin/invoices']);
      toast({
        title: 'Success',
        description: 'Invoice marked as paid'
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update invoice',
        variant: 'destructive'
      });
    }
  });

  // Export invoice mutation
  const exportInvoiceMutation = useMutation({
    mutationFn: ({ invoiceId, format }) => apiRequest('GET', `/api/admin/invoices/${invoiceId}/export?format=${format}`),
    onSuccess: (data, variables) => {
      // Handle file download
      const blob = new Blob([data], { 
        type: variables.format === 'pdf' ? 'application/pdf' : 'text/csv' 
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `invoice-${variables.invoiceId}.${variables.format}`;
      a.click();
      window.URL.revokeObjectURL(url);
      
      toast({
        title: 'Success',
        description: `Invoice exported as ${variables.format.toUpperCase()}`
      });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to export invoice',
        variant: 'destructive'
      });
    }
  });

  const resetNewInvoice = () => {
    setNewInvoice({
      providerId: '',
      bookingId: '',
      items: [{ description: '', hours: '', rate: '', amount: '' }],
      notes: ''
    });
  };

  const addInvoiceItem = () => {
    setNewInvoice(prev => ({
      ...prev,
      items: [...prev.items, { description: '', hours: '', rate: '', amount: '' }]
    }));
  };

  const updateInvoiceItem = (index, field, value) => {
    setNewInvoice(prev => ({
      ...prev,
      items: prev.items.map((item, i) => {
        if (i === index) {
          const updatedItem = { ...item, [field]: value };
          // Auto-calculate amount if hours and rate are provided
          if (field === 'hours' || field === 'rate') {
            const hours = field === 'hours' ? parseFloat(value) || 0 : parseFloat(item.hours) || 0;
            const rate = field === 'rate' ? parseFloat(value) || 0 : parseFloat(item.rate) || 0;
            updatedItem.amount = (hours * rate).toFixed(2);
          }
          return updatedItem;
        }
        return item;
      })
    }));
  };

  const removeInvoiceItem = (index) => {
    setNewInvoice(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index)
    }));
  };

  // Filter invoices
  const filteredInvoices = invoices.filter(invoice => {
    const matchesSearch = invoice.invoiceNumber?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.providerName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.customerName?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || invoice.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case 'draft': return 'secondary';
      case 'sent': return 'outline';
      case 'paid': return 'default';
      case 'overdue': return 'destructive';
      default: return 'outline';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'draft': return 'text-gray-600';
      case 'sent': return 'text-blue-600';
      case 'paid': return 'text-green-600';
      case 'overdue': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const handleCreateInvoice = () => {
    const totalAmount = newInvoice.items.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0);
    createInvoiceMutation.mutate({
      ...newInvoice,
      totalAmount: totalAmount.toFixed(2)
    });
  };

  const handleMarkPaid = (invoiceId) => {
    if (window.confirm('Mark this invoice as paid?')) {
      markPaidMutation.mutate(invoiceId);
    }
  };

  const handleExport = (invoiceId, format) => {
    exportInvoiceMutation.mutate({ invoiceId, format });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Invoice System</CardTitle>
          <CardDescription>Manage invoices and billing for completed services</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search invoices..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="sent">Sent</SelectItem>
                <SelectItem value="paid">Paid</SelectItem>
                <SelectItem value="overdue">Overdue</SelectItem>
              </SelectContent>
            </Select>
            <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Invoice
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Create New Invoice</DialogTitle>
                  <DialogDescription>Generate an invoice for completed services</DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="provider">Service Provider</Label>
                      <Select value={newInvoice.providerId} onValueChange={(value) => setNewInvoice({ ...newInvoice, providerId: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select provider" />
                        </SelectTrigger>
                        <SelectContent>
                          {providers.filter(p => p.status === 'approved').map(provider => (
                            <SelectItem key={provider.id} value={provider.id.toString()}>
                              {provider.businessName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="booking">Related Booking</Label>
                      <Select value={newInvoice.bookingId} onValueChange={(value) => setNewInvoice({ ...newInvoice, bookingId: value })}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select booking" />
                        </SelectTrigger>
                        <SelectContent>
                          {bookings.map(booking => (
                            <SelectItem key={booking.id} value={booking.id.toString()}>
                              #{booking.id} - {booking.serviceName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Invoice Items</Label>
                    <div className="space-y-3 mt-2">
                      {newInvoice.items.map((item, index) => (
                        <div key={index} className="grid grid-cols-12 gap-2 items-end">
                          <div className="col-span-4">
                            <Input
                              placeholder="Description"
                              value={item.description}
                              onChange={(e) => updateInvoiceItem(index, 'description', e.target.value)}
                            />
                          </div>
                          <div className="col-span-2">
                            <Input
                              placeholder="Hours"
                              type="number"
                              step="0.5"
                              value={item.hours}
                              onChange={(e) => updateInvoiceItem(index, 'hours', e.target.value)}
                            />
                          </div>
                          <div className="col-span-2">
                            <Input
                              placeholder="Rate/hr"
                              type="number"
                              step="0.01"
                              value={item.rate}
                              onChange={(e) => updateInvoiceItem(index, 'rate', e.target.value)}
                            />
                          </div>
                          <div className="col-span-2">
                            <Input
                              placeholder="Amount"
                              value={item.amount}
                              readOnly
                              className="bg-gray-50"
                            />
                          </div>
                          <div className="col-span-2">
                            {newInvoice.items.length > 1 && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => removeInvoiceItem(index)}
                                className="text-red-600"
                              >
                                Remove
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={addInvoiceItem}
                      className="mt-2"
                    >
                      Add Item
                    </Button>
                  </div>

                  <div>
                    <Label htmlFor="notes">Notes</Label>
                    <Input
                      id="notes"
                      placeholder="Additional notes or terms"
                      value={newInvoice.notes}
                      onChange={(e) => setNewInvoice({ ...newInvoice, notes: e.target.value })}
                    />
                  </div>

                  <div className="bg-gray-50 p-3 rounded">
                    <div className="text-right">
                      <span className="text-sm text-gray-600">Total Amount: </span>
                      <span className="text-lg font-bold">
                        QAR {newInvoice.items.reduce((sum, item) => sum + (parseFloat(item.amount) || 0), 0).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreateInvoice} disabled={createInvoiceMutation.isPending}>
                    {createInvoiceMutation.isPending ? 'Creating...' : 'Create Invoice'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Provider</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">Loading...</TableCell>
                  </TableRow>
                ) : filteredInvoices.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center">No invoices found</TableCell>
                  </TableRow>
                ) : (
                  filteredInvoices.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-gray-400" />
                          <span className="font-medium">{invoice.invoiceNumber}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{invoice.providerName}</div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{invoice.customerName}</div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          {new Date(invoice.createdAt).toLocaleDateString()}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <DollarSign className="h-4 w-4 text-gray-400" />
                          <span className="font-medium">QAR {invoice.totalAmount}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(invoice.status)} className={getStatusColor(invoice.status)}>
                          {invoice.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleExport(invoice.id, 'pdf')}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                          {invoice.status !== 'paid' && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleMarkPaid(invoice.id)}
                              className="text-green-600 hover:text-green-700"
                            >
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Invoice Statistics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Invoices</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{invoices.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Payment</CardTitle>
            <XCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {invoices.filter(inv => inv.status === 'sent').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Paid Invoices</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              {invoices.filter(inv => inv.status === 'paid').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              QAR {invoices.filter(inv => inv.status === 'paid')
                .reduce((sum, inv) => sum + parseFloat(inv.totalAmount || 0), 0)
                .toFixed(2)}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}