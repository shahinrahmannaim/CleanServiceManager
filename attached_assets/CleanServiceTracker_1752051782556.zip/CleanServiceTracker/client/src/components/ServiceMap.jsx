import { useState, useEffect } from 'react';
import { MapPin, Phone, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ServiceMap = ({ serviceProviders = [] }) => {
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [mapLoaded, setMapLoaded] = useState(false);

  // Qatar locations for service providers
  const qatarLocations = [
    { id: 1, name: "Doha Central", address: "Doha, Qatar", lat: 25.2854, lng: 51.5310 },
    { id: 2, name: "Al Rayyan", address: "Al Rayyan, Qatar", lat: 25.2917, lng: 51.4244 },
    { id: 3, name: "Al Wakrah", address: "Al Wakrah, Qatar", lat: 25.1716, lng: 51.6067 },
    { id: 4, name: "Umm Salal", address: "Umm Salal, Qatar", lat: 25.4097, lng: 51.4069 },
    { id: 5, name: "Al Khor", address: "Al Khor, Qatar", lat: 25.6814, lng: 51.4969 }
  ];

  useEffect(() => {
    // Load Google Maps API
    if (!window.google) {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=YOUR_GOOGLE_MAPS_API_KEY&libraries=places`;
      script.async = true;
      script.defer = true;
      script.onload = () => setMapLoaded(true);
      document.head.appendChild(script);
    } else {
      setMapLoaded(true);
    }
  }, []);

  useEffect(() => {
    if (mapLoaded && window.google) {
      initializeMap();
    }
  }, [mapLoaded]);

  const initializeMap = () => {
    const map = new window.google.maps.Map(document.getElementById('service-map'), {
      center: { lat: 25.2854, lng: 51.5310 }, // Doha center
      zoom: 10,
      styles: [
        {
          featureType: 'all',
          elementType: 'geometry.fill',
          stylers: [{ color: '#f5f5f5' }]
        },
        {
          featureType: 'water',
          elementType: 'geometry',
          stylers: [{ color: '#e9e9e9' }]
        }
      ]
    });

    // Add markers for each location
    qatarLocations.forEach((location, index) => {
      const marker = new window.google.maps.Marker({
        position: { lat: location.lat, lng: location.lng },
        map: map,
        title: location.name,
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="20" cy="20" r="18" fill="#ef4444" stroke="white" stroke-width="4"/>
              <circle cx="20" cy="20" r="8" fill="white"/>
            </svg>
          `),
          scaledSize: new window.google.maps.Size(40, 40)
        }
      });

      const infoWindow = new window.google.maps.InfoWindow({
        content: `
          <div class="p-4 max-w-sm">
            <h3 class="font-bold text-lg text-gray-900 mb-2">${location.name}</h3>
            <p class="text-gray-600 mb-3">${location.address}</p>
            <div class="flex items-center gap-2 mb-3">
              <div class="flex items-center">
                ${Array(5).fill(0).map(() => '<span class="text-yellow-400">★</span>').join('')}
              </div>
              <span class="text-sm text-gray-500">(4.9)</span>
            </div>
            <button class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium">
              Book Service
            </button>
          </div>
        `
      });

      marker.addListener('click', () => {
        infoWindow.open(map, marker);
        setSelectedProvider(location);
      });
    });
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Find Cleaning Services Near You
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover trusted cleaning professionals across Qatar. Available in Doha, Al Rayyan, Al Wakrah, and more.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Service Locations List */}
          <div className="lg:col-span-1">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Service Areas</h3>
            <div className="space-y-4">
              {qatarLocations.map((location) => (
                <div
                  key={location.id}
                  className={`p-4 rounded-xl border transition-all duration-200 cursor-pointer ${
                    selectedProvider?.id === location.id
                      ? 'border-red-500 bg-red-50'
                      : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-md'
                  }`}
                  onClick={() => setSelectedProvider(location)}
                >
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-red-500 mt-1" />
                    <div className="flex-1">
                      <h4 className="font-semibold text-gray-900">{location.name}</h4>
                      <p className="text-sm text-gray-600 mb-2">{location.address}</p>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center">
                          {Array(5).fill(0).map((_, i) => (
                            <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          ))}
                        </div>
                        <span className="text-sm text-gray-500">(4.9)</span>
                      </div>
                    </div>
                  </div>
                  <Button className="w-full mt-3 bg-red-500 hover:bg-red-600">
                    Book Now
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Google Map */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="h-96 lg:h-[500px] relative">
                {!mapLoaded ? (
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
                    <div className="text-center">
                      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500 mx-auto mb-4"></div>
                      <p className="text-gray-600">Loading Qatar service locations...</p>
                    </div>
                  </div>
                ) : (
                  <div id="service-map" className="w-full h-full"></div>
                )}
              </div>
              {selectedProvider && (
                <div className="p-6 border-t bg-gray-50">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-lg text-gray-900">{selectedProvider.name}</h4>
                      <p className="text-gray-600">{selectedProvider.address}</p>
                    </div>
                    <div className="flex gap-3">
                      <Button variant="outline" size="sm">
                        <Phone className="h-4 w-4 mr-2" />
                        Call
                      </Button>
                      <Button size="sm" className="bg-red-500 hover:bg-red-600">
                        Book Service
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Service Coverage Info */}
        <div className="mt-16 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-lg">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Complete Qatar Coverage</h3>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Our professional cleaning services are available across all major cities and areas in Qatar. 
              From residential homes to commercial offices, we've got you covered.
            </p>
            <div className="grid md:grid-cols-5 gap-4 max-w-4xl mx-auto">
              {['Doha', 'Al Rayyan', 'Al Wakrah', 'Umm Salal', 'Al Khor'].map((city) => (
                <div key={city} className="bg-blue-50 rounded-lg p-4">
                  <MapPin className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                  <p className="font-medium text-gray-900">{city}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServiceMap;