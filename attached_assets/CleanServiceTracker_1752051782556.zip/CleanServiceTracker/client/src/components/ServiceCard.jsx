import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Home, Building, Sparkles, Hammer, Grid, Zap } from "lucide-react";

const serviceIcons = {
  home: Home,
  office: Building,
  deep: Sparkles,
  construction: Hammer,
  carpet: Grid,
  window: Zap
};

const serviceImages = {
  home: "https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=600&h=400&fit=crop",
  office: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=600&h=400&fit=crop",
  deep: "https://images.unsplash.com/photo-1527515637462-cff94eecc1ac?w=600&h=400&fit=crop",
  construction: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&h=400&fit=crop",
  carpet: "https://images.unsplash.com/photo-1628177142898-93e36e4e3a50?w=600&h=400&fit=crop",
  window: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop"
};

export default function ServiceCard({ service }) {
  const IconComponent = serviceIcons[service.category] || Sparkles;
  const imageUrl = serviceImages[service.category] || serviceImages.home;
  
  return (
    <Card className="service-card bg-white rounded-3xl shadow-lg hover:shadow-xl transition-all duration-300">
      <CardContent className="p-8">
        <img
          src={imageUrl}
          alt={service.name}
          className="w-full h-48 object-cover rounded-2xl mb-6"
        />
        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mb-4">
          <IconComponent className="h-8 w-8 text-white" />
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-3">{service.name}</h3>
        <p className="text-gray-600 mb-6 line-clamp-3">{service.description}</p>
        <div className="flex justify-between items-center">
          <span className="text-2xl font-bold text-blue-500">${service.price}</span>
          <Link href={`/book/${service.id}`}>
            <Button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-xl font-semibold transition-colors duration-300">
              Book Now
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
