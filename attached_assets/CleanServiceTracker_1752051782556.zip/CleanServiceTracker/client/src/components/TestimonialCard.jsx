import { Card, CardContent } from "@/components/ui/card";
import { Star } from "lucide-react";

export default function TestimonialCard({ testimonial }) {
  return (
    <Card className="bg-gray-50 rounded-3xl hover:shadow-lg transition-shadow duration-300">
      <CardContent className="p-8">
        <div className="flex items-center mb-4">
          <img
            src={testimonial.image}
            alt={testimonial.name}
            className="w-16 h-16 rounded-full object-cover mr-4"
          />
          <div>
            <h4 className="font-bold text-gray-900">{testimonial.name}</h4>
            <div className="flex text-yellow-500">
              {[...Array(testimonial.rating)].map((_, i) => (
                <Star key={i} className="h-4 w-4 fill-current" />
              ))}
            </div>
          </div>
        </div>
        <p className="text-gray-600 italic">"{testimonial.review}"</p>
      </CardContent>
    </Card>
  );
}
