# Panaroma Cleaning Services - Local Setup Guide

## Prerequisites

Before running the project locally, ensure you have the following installed:

- **Node.js** (version 18 or higher)
- **npm** (comes with Node.js)
- **PostgreSQL** (version 12 or higher)
- **Git**

## Installation Steps

### 1. Clone the Repository
```bash
git clone <your-repository-url>
cd panaroma-cleaning-services
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Database Setup

#### Option A: Local PostgreSQL
1. Install PostgreSQL on your machine
2. Create a new database:
```sql
CREATE DATABASE panaroma_cleaning;
```

3. Create a `.env` file in the root directory:
```env
DATABASE_URL=postgresql://username:password@localhost:5432/panaroma_cleaning
SESSION_SECRET=your-super-secret-session-key-here
JWT_SECRET=your-jwt-secret-key-here
NODE_ENV=development
```

#### Option B: Cloud Database (Neon/Supabase)
1. Create a free account on [Neon](https://neon.tech) or [Supabase](https://supabase.com)
2. Create a new PostgreSQL database
3. Copy the connection string to your `.env` file:
```env
DATABASE_URL=postgresql://username:password@host:port/database
SESSION_SECRET=your-super-secret-session-key-here
JWT_SECRET=your-jwt-secret-key-here
NODE_ENV=development
```

### 4. Initialize Database Schema
```bash
npm run db:push
```

### 5. Seed Initial Data (Optional)
The application will automatically create sample services and providers when you first run it.

### 6. Start Development Server
```bash
npm run dev
```

The application will be available at:
- **Frontend & Backend**: http://localhost:5000

## Project Structure

```
panaroma-cleaning-services/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utility functions
├── server/                 # Express backend
│   ├── routes.ts           # API routes
│   ├── storage.ts          # Database operations
│   └── index.ts            # Server entry point
├── shared/                 # Shared types and schemas
│   └── schema.ts           # Database schema & types
├── package.json
└── vite.config.ts
```

## Available Scripts

- `npm run dev` - Start development server (both frontend and backend)
- `npm run build` - Build production version
- `npm run start` - Start production server
- `npm run db:push` - Push database schema changes
- `npm run db:studio` - Open Drizzle Studio (database GUI)

## Features

### Core Functionality
- **User Authentication** - JWT-based with role management (customer, provider, admin)
- **Service Management** - CRUD operations for cleaning services
- **Provider Network** - Service provider profiles and management
- **Booking System** - Service booking with status tracking
- **Payment Integration** - Payment status and invoice management
- **Review System** - Customer reviews and ratings

### Technical Features
- **Modern React** - Hooks, context, and functional components
- **TypeScript** - Type-safe development (backend only)
- **Tailwind CSS** - Utility-first styling
- **Shadcn/UI** - Pre-built accessible components
- **TanStack Query** - Server state management
- **Drizzle ORM** - Type-safe database operations
- **PostgreSQL** - Reliable relational database

## Admin Access

Default admin credentials:
- **Username**: admin
- **Email**: admin@panaroma.qa
- **Password**: Admin123!

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user

### Services
- `GET /api/services` - Get all services
- `POST /api/services` - Create service (admin only)
- `PUT /api/services/:id` - Update service (admin only)
- `DELETE /api/services/:id` - Delete service (admin only)

### Providers
- `GET /api/providers` - Get all providers
- `POST /api/providers` - Create provider
- `PUT /api/providers/:id` - Update provider

### Bookings
- `GET /api/bookings` - Get user bookings
- `POST /api/bookings` - Create booking
- `PUT /api/bookings/:id` - Update booking status

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Verify DATABASE_URL in .env file
   - Ensure PostgreSQL is running
   - Check database credentials

2. **Port Already in Use**
   - Kill process using port 5000: `lsof -ti:5000 | xargs kill -9`
   - Or change port in vite.config.ts

3. **Module Not Found Errors**
   - Delete node_modules and package-lock.json
   - Run `npm install` again

4. **Build Errors**
   - Clear cache: `npm run build -- --force`
   - Check for TypeScript errors

### Environment Variables

Required environment variables:
```env
DATABASE_URL=postgresql://...     # Database connection string
SESSION_SECRET=...               # Session encryption key
JWT_SECRET=...                   # JWT signing key
NODE_ENV=development             # Environment mode
```

## Deployment

### Local Production Build
```bash
npm run build
npm start
```

### Cloud Deployment (Replit)
The project is configured for Replit deployment:
1. Push code to repository
2. Connect to Replit
3. Set environment variables
4. Deploy automatically

## Support

For issues or questions:
1. Check this documentation
2. Review error logs in console
3. Ensure all dependencies are installed
4. Verify database connection

## Qatar Market Features

- **Local Cities**: Doha, Al Rayyan, Al Wakrah, Umm Salal, Al Khor
- **Currency**: Qatari Riyal (QAR)
- **Local Contact**: +974 phone numbers
- **Arabic/English**: RTL support ready