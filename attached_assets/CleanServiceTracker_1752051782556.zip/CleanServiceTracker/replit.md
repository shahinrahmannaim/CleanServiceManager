# Panaroma Cleaning Services Platform

## Overview

Panaroma is a full-stack web application for a cleaning services marketplace. It connects customers with cleaning service providers, offering features like service booking, user management, payment processing, and review systems. The application is built with a modern React frontend and Node.js/Express backend, using PostgreSQL for data persistence.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **UI Framework**: Shadcn/UI components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system
- **Form Handling**: React Hook Form with Zod validation
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: JWT-based authentication with bcrypt password hashing
- **Session Management**: Cookie-based sessions with PostgreSQL session store
- **Development Server**: Hot-reload development environment with Vite integration

### Database Architecture
- **Database**: PostgreSQL (configured for Neon serverless)
- **Schema Management**: Drizzle Kit for migrations
- **Connection**: Connection pooling with @neondatabase/serverless
- **Data Models**: Users, Services, Bookings, Payments, Reviews with proper relationships

## Key Components

### Authentication System
- User registration and login with role-based access (customer, provider, admin)
- JWT token generation and validation
- Password hashing with bcrypt
- Session persistence with cookies

### Service Management
- Service catalog with categories (home, office, deep cleaning, etc.)
- Service pricing and duration management
- Image support for service listings
- Active/inactive service states

### Booking System
- Multi-step booking process
- Service selection and scheduling
- Address and special instructions capture
- Booking status management (pending, confirmed, in_progress, completed, cancelled)

### Payment Integration
- Payment status tracking (pending, paid, failed, refunded)
- Integration-ready payment system structure
- Booking-payment relationship management

### User Roles & Permissions
- Customer role: Book services, view bookings, leave reviews
- Provider role: Manage service offerings, handle bookings
- Admin role: System administration capabilities

## Data Flow

### User Registration/Authentication Flow
1. User submits registration form with role selection
2. Backend validates data and hashes password
3. User record created in database
4. JWT token generated and sent via cookie
5. Frontend redirects to dashboard

### Service Booking Flow
1. Customer browses available services
2. Selects service and fills booking form
3. Backend creates booking record with pending status
4. Payment record initialized
5. Booking confirmation sent to customer
6. Provider can accept/manage booking

### Service Management Flow
1. Provider creates/updates service offerings
2. Services stored with categories and pricing
3. Customers can browse active services
4. Booking system links customers to services

## External Dependencies

### Frontend Dependencies
- React ecosystem (React, React DOM, React Hook Form)
- UI Libraries (Radix UI components, Lucide React icons)
- State Management (TanStack Query)
- Styling (Tailwind CSS, class-variance-authority)
- Utilities (date-fns, clsx, zod for validation)

### Backend Dependencies
- Express.js framework and middleware
- Database (Drizzle ORM, PostgreSQL drivers)
- Authentication (bcrypt, jsonwebtoken)
- Session management (connect-pg-simple, cookie-parser)
- Development tools (tsx for TypeScript execution)

### Build & Development Tools
- Vite for frontend bundling and development
- TypeScript for type safety
- ESBuild for backend bundling
- Drizzle Kit for database migrations

## Deployment Strategy

### Development Environment
- Replit-based development with hot-reload
- Local PostgreSQL database connection
- Vite dev server with Express API proxy
- Port 5000 for development server

### Production Build
- Frontend: Vite build to `dist/public`
- Backend: ESBuild bundle to `dist/index.js`
- Single server deployment serving both API and static files
- Environment variables for database connection

### Database Deployment
- PostgreSQL database (configured for Neon)
- Schema migrations managed by Drizzle Kit
- Connection pooling for production scalability

### Platform Configuration
- Replit autoscale deployment target
- Node.js 20 runtime environment
- Automated build and start scripts
- Health check on port 5000

## Changelog

```
Changelog:
- June 25, 2025. Initial setup
- June 25, 2025. Added service providers table and API endpoints
- June 25, 2025. Updated brand colors to dark blue and tomato red theme
- June 25, 2025. Simplified navbar with aligned navigation items
- June 25, 2025. Fixed login/register page visibility with proper background contrast
- June 25, 2025. Updated hero section with modern cleaning image and enhanced logo visibility
- June 25, 2025. Fixed missing content in customer testimonials and pricing sections
- June 25, 2025. Updated hero section with modern cleaning image and enhanced logo visibility
- June 25, 2025. Customized for Qatar market with Doha locations and QAR pricing
- June 25, 2025. Added Google Maps integration for service vendor locations
- June 26, 2025. Enhanced landing page with vibrant animations and interactive elements
- June 26, 2025. Updated login/register pages with Panorama logo and brand colors
- June 26, 2025. Removed first/last name fields from registration form
- June 26, 2025. Added forgot password functionality with dedicated page
- June 26, 2025. Implemented Fuse.js fuzzy search for services with real-time filtering
- June 26, 2025. Updated location selector with comprehensive Qatar cities list
- June 26, 2025. Transformed landing page with futuristic cyberpunk dark theme design
- June 26, 2025. Added next-generation UI elements: holographic stats, neon effects, matrix animations
- June 26, 2025. Updated service section with realistic cleaning service descriptions and real images
- June 26, 2025. Converted login and register pages to modal popups in navbar
- June 26, 2025. Redesigned hero section with clear cleaning service messaging and professional imagery
- June 26, 2025. Updated process steps and feature descriptions to be more straightforward and professional
- June 26, 2025. Completely redesigned hero section with "Personal Assistant" concept using professional background image
- June 26, 2025. Added integrated search interface with location selector and service categories grid
- June 26, 2025. Implemented promotional banner for installment payment options
- June 27, 2025. Redesigned entire landing page with modern professional template style
- June 27, 2025. Updated hero section with "Clean Spaces, Happy Lives" messaging and professional layout
- June 27, 2025. Added service categories section with detailed pricing and features for Qatar market
- July 2, 2025. Fixed database schema issues preventing user registration
- July 2, 2025. Added professional footer component to all pages
- July 2, 2025. Implemented loading spinners and page loaders for better UX
- July 2, 2025. Fixed navbar visibility issues across all pages
- July 2, 2025. Created comprehensive local setup documentation
- July 2, 2025. Enhanced registration form with phone field and password validation
- July 2, 2025. Made login/register modals transparent with backdrop blur
- July 3, 2025. Fixed authentication system with proper session-based authentication
- July 3, 2025. Implemented comprehensive admin dashboard with user management system
- July 3, 2025. Added admin panel access control based on user roles
- July 3, 2025. Created admin routes for CRUD operations on users
- July 3, 2025. Started implementing core admin features: bookings management and service provider management
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
Brand colors: Dark blue and tomato red (from Panaroma logo)
Navigation: Simple navbar with logo, Services, Login, Join Us
Target market: Qatar (Doha, Al Rayyan, Al Wakrah, Umm Salal, Al Khor)
Currency: Qatari Riyal (QAR)
Local features: Google Maps integration for service locations
```